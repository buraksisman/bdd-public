# 1 Ekim 2026 — 0.3.2 immutable image dağıtım modeli

0.3.2 deployment format 2, müşteri hostundaki Next.js build işlemini kaldırır.
Uygulama yalnız tag pipeline'ında build edilir; uygulama ve vendor image'ları OCI
digest ile sabitlenir. Kaynak ağaç doğrudan müşteri paketi üretmeyi reddeder.
Finalizer; `src`, `public`, Dockerfile ve npm dosyalarını dışarıda bırakan deployment
root'u oluşturur. 0.2.8 format 1 backup'ları eski build context'iyle restore
edilebilir ve 0.2.8 → 0.3.2 geçişi açıkça desteklenir.

Eklenen release kontrolleri:

- protected tag ile GitHub Actions release pipeline;
- GHCR'ye tek app build/push ve provenance attestation;
- bütün vendor tag'lerini digest'e çözme;
- kaynak kodsuz deployment arşivi, manifest ve SHA256;
- release yayınlanmadan clean install/update/backup/restore integration;
- `internal → pilot → stable` promotion workflow'u;
- secret içermeyen, Git tarafından ignore edilen müşteri sürüm envanteri.

Yerel sonuçlar: 39/39 Python testi, 7/7 Node testi, kaynak tanımı doğrulaması,
sahte digest'lerle finalize edilen kaynak kodsuz artifact/manifest, production
Compose parser, temiz npm kurulumu, production webpack/TypeScript build ve iki
runtime müşteri ayarıyla standalone HTTP smoke testi geçti. npm audit 0 bilinen
bulgu bildirdi.

Bu çalışma kopyasında Git remote ve çalışan Docker daemon bulunmadığı için gerçek
GHCR push, gerçek digest çözümü, tag workflow'u ve 0.3.2 final müşteri arşivi yerel
olarak üretilemez. Bunlar private GitHub repository ayarlandıktan sonra `v0.3.2`
tag pipeline'ının kabul kapılarıdır. Kaynak ağacındaki `finalized=false` bilinçlidir;
bu dosya müşteriye verilecek artifact değildir.

## Önceki 0.2.8 kaydı

0.2.8, 0.2.7 workflow davranışını koruyarak production preflight, yarım ilk
kurulum kurtarma, workflow runtime smoke kontrolleri, Phone Number ID runtime
doğrulaması, backup retention, güvenli cleanup ve teknisyen odaklı tek production
rehberi ekler. Inbound ve outbound workflow dosyalarının SHA256 değerleri 0.2.7
ile aynıdır.

| Kontrol | Sonuç |
|---|---|
| Python deployment testleri | 34/34 geçti |
| Node.js runtime/bootstrap testleri | 7/7 geçti, Node.js 22.22.0 |
| `deploy/manage.py validate` | Geçti, sürüm 0.2.8 |
| Production Compose şema kontrolü | Geçti, Compose 2.39.4 standalone parser |
| Temiz paket kaynağında `npm ci --offline` | Geçti, 0 bilinen npm açığı |
| Temiz production build ve TypeScript | Webpack yolu geçti; standalone runtime smoke iki müşteri ayarıyla geçti |
| Release manifest ve companion SHA256 | Geçti; arşiv yeniden açılıp manifest doğrulandı |
| Clean install/configure/update/backup/restore integration senaryosu | Test kodu genişletildi; bu makinede Docker daemon olmadığı için çalıştırılamadı |
| n8n Schedule Trigger | Integration testinde published trigger execution kaydı bekleniyor; daemon nedeniyle burada çalıştırılmadı |
| Inbound/duplicate, mock outbound `pending → sent`, delivered/read | Integration testine eklendi; daemon nedeniyle burada çalıştırılmadı |

`python3 deploy/tests/integration.py` gerçekten çalıştırıldı ve install preflight'ta
durdu: aktif context `desktop-linux`, Docker daemon socket'i erişilemez, Compose ve
buildx eklentileri bu host kurulumunda yok. Bu nedenle Docker image build'i, temiz
DB bootstrap'ı ve çalışan n8n execution sonuçları bu makine için doğrulanmış olarak
raporlanmıyor. Test, Docker Engine + Compose + buildx bulunan izole Linux runner'da
release kabulünden önce çalıştırılmalıdır.

Varsayılan Turbopack build bu çalışma ortamında iç process için localhost portu
açarken macOS sandbox tarafından `EPERM` ile durduruldu. Aynı temiz arşivde resmi
webpack production build, TypeScript ve standalone HTTP smoke testi geçti. Linux
Docker içindeki varsayılan Turbopack build sonucu, yukarıdaki Docker integration
sınırına dahildir.

## Önceki 0.2.7 kaydı

n8n 2.40'ta deprecated olan `WEBHOOK_URL`, `N8N_WEBHOOK_URL` ile değiştirildi.
Başarılı, hatalı ve manuel execution verileri kaydedilir; pruning 24 saat ve
en fazla 5.000 execution ile sınırlıdır. Docker integration senaryosu artık
workflow'ları sahte Meta değerleriyle publish eder ve outbound Schedule Trigger'ın
n8n SQLite `execution_entity` tablosunda otomatik `trigger` execution oluşturduğunu
45 saniye içinde doğrular. WhatsApp inbound/outbound JSON dosyaları ve Meta test
numarası davranışı değiştirilmedi.

## Önceki 0.2.6 kaydı

0.2.5 gerçek kurulumunda DB, Storage, Auth, Realtime, REST ve Gateway healthy
oldu; migration'lar ve ilk admin oluşturma tamamlandı. Kurulum yalnızca inbound
workflow içindeki, mevcut olmayan `Doküman İzinli mi?` node referansında durdu.
`Medya Var mı?` ve `Medya İzinli mi?` IF node'larındaki eski `true`/`false`
bağlantı alanları kaldırıldı; akış standart `main[0]` ve `main[1]` dallarıyla
tanımlandı. Altyapı/bootstrap yapılandırması değiştirilmedi. Yarım 0.2.5
kurulumuna devam etmek için [0.2.6 rehberini](RECOVERY_0.2.6_TR.md) kullanın.

## Önceki 0.2.5 kaydı

Temiz Docker logları iki başlangıç yarışını gösterdi. Storage gerçekte
`127.0.0.1:5000/status` üzerinde çalışırken `localhost` healthcheck'i bağlantıyı
reddetti. DB ise geçici initialization sunucusu `pg_isready` sonucunu başarılı
verdiğinde, Supabase bootstrap bitmeden bağımlı servisleri başlattı. Storage
healthcheck IPv4 adresine sabitlendi. DB healthcheck artık gerekli rollerin parolaları,
`_realtime` şeması ve `_supabase` veritabanı birlikte hazır olduğunda başarılıdır.

## Önceki 0.2.4 kaydı

Gerçek temiz DB logu, Supabase bootstrap'ın temel rolleri oluşturduğunu ancak
`99-roles.sql` çalıştığı sırada `supabase_functions_admin` rolünün henüz
bulunmadığını gösterdi. Bu deployment Edge Functions içermediğinden o rolün parola
güncellemesi kaldırıldı. Auth sahiplik, `_supabase`, `_realtime` ve koşullu config
seed düzeltmeleri korundu. Yeni kurulumlarda 0.2.5 kullanılmalıdır.

## Önceki 0.2.3 kaydı

Temiz Docker testi, 0.2.2'deki `POSTGRES_USER=postgres` ayarının Supabase image
rol bootstrap'ını bozduğunu gösterdi. Ayar kaldırıldı; `_supabase` veritabanı ve
`_realtime` şeması doğrudan `supabase_admin` sahipliğiyle oluşturuluyor.
`auth-ownership.sql` ve koşullu config seed düzeltmeleri korundu. Yarım ilk
kurulum için 0.2.5 kullanılmalıdır.

## Önceki 0.2.2 kaydı

`POSTGRES_USER=postgres`, koşullu Auth helper ownership aktarımı ve `conf.d`
varlığına bağlı config seed işlemi eklendi. 22 Python testi geçti. Gerçek Docker
başlangıcı henüz bu geliştirme makinesinde doğrulanmadı. Yarım ilk kurulum için
[0.2.2 kurtarma rehberini](RECOVERY_0.2.2_TR.md) kullanın.

## Önceki 0.2.1 kaydı

Boş PostgreSQL config bind mount düzeltildi; fatal-only log filtresi kaldırıldı. 21 Python testi geçti. Gerçek Docker başlangıcı henüz doğrulanmadı. Ayrıntılar: [kurtarma rehberi](RECOVERY_0.2.1_TR.md). Aşağıdaki kayıt 0.2.0 için yapılan önceki kontrollerdir.

# Doğrulama kaydı — 30 Eylül 2026

Dağıtım sürümü: **0.2.0**. Bu kayıt kaynak ve uygulama doğrulamasıdır; müşteri sunucusunda tamamlanmış kurulum raporu değildir.

| Kontrol | Sonuç |
|---|---|
| Python dağıtım testleri | 19/19 geçti |
| Node.js runtime ayarları ve ilk yönetici oluşturma testleri | 7/7 geçti |
| Yerel HTTP Compose şema kontrolü | Geçti, Docker Compose 2.39.4 parser ile |
| Üretim HTTPS Compose şema kontrolü | Geçti, Docker Compose 2.39.4 parser ile |
| Temiz `npm ci` ve `npm run build` | Geçti, Node.js 22.22.0 / Next.js 16.3.8 |
| Build içindeki TypeScript kontrolü | Geçti |
| Aynı standalone build ile iki farklı müşteri URL/key ayarı | Her iki localhost smoke testi geçti |
| HTML içinde service-role anahtarı bulunmaması | Smoke testte doğrulandı |
| Son kilit dosyasıyla npm bağımlılık taraması | 0 bilinen açık bildirildi |
| Kaynak paketleme ve manifest doğrulama | Unit testte doğrulandı; env/runtime veri dışlama ve değiştirilmiş kaynak reddi test edildi |
| SQL migration transaction/gerçek PostgreSQL çalışması | Bu makinede çalıştırılamadı |
| Docker image build ve tüm servislerin birlikte açılması | Bu makinede çalıştırılamadı |
| Gerçek müşteri verisiyle güncelleme ve fiziksel restore | Yapılmadı |
| Meta webhook, gerçek WhatsApp gönderimi ve medya | Yapılmadı |
| GitHub Actions workflow'u | Dosya eklendi; GitHub üzerinde bu oturumda tetiklenmedi |

## Ortam sınırları

Yerel Docker CLI mevcut olsa da Docker daemon'a bağlantı kurulamadı. Docker Desktop uygulaması bulunamadı ve Compose eklentisi eksik/kırık bağlantıydı. Şema doğrulaması için geçici klasöre standalone Compose parser indirildi; bu işlem konteyner çalıştırmaz.

Sistemin varsayılan Node.js'i 12.16.3 olduğundan testlerde geçici klasörde Node.js 22.22.0 kullanıldı. Mevcut `node_modules` içindeki SWC ikili dosyası macOS tarafından reddedildiği için build, ayrı geçici kaynak kopyasında temiz `npm ci` ile yapıldı. Son build'deki uygulama `.ts/.tsx`, Next.js ayarı, `package.json` ve kilit dosyası çalışma klasörüyle byte düzeyinde karşılaştırıldı; fark bulunmadı. Sistemin global Node kurulumu değiştirilmedi.

Next.js 16.2.4'ten 16.3.8'e geçirildi; resmî [16.3.8 sürüm notu](https://github.com/vercel/next.js/releases/tag/v16.3.8) güvenlik düzeltmelerini listeler. Ayrıca `npm audit fix --package-lock-only` ile mevcut semver aralıklarındaki düzeltmeler uygulandı; `--force` kullanılmadı. Sıfır npm bulgusu, konteyner image'ları veya uygulamanın tüm erişim kuralları için güvenlik denetimi anlamına gelmez.

## Müşteriye geçişten önce kalan kontrol

Docker Engine + Compose + buildx olan izole bir Linux test sunucusunda:

```bash
python3 deploy/tests/integration.py
```

Bu senaryo temiz kurulum, migration'ların tekrar çalıştırılabilirliği, eski dosya checksum değişikliğinin reddi, mevcut müşteri kaydını koruyarak sürüm yükseltme, başarısız migration rollback'i ve fiziksel yedekten eski sürüme dönüşü kapsar. Ardından test Meta hesabıyla gerçek mesaj ve dosya kabul testi yapılmalıdır.

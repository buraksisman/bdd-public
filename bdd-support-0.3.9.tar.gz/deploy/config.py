"""Pure deployment rendering. No network or Docker access during import."""
import base64
import hashlib
import hmac
import json
import re
import secrets
import time
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
CORE = ['db', 'auth', 'rest', 'realtime', 'storage', 'gateway']
WORKFLOWS = ['whatsapp-verify', 'whatsapp-inbound', 'whatsapp-outbound']


def release(root=ROOT):
    return json.loads((root / 'deploy/release.json').read_text())


def source_files(root=ROOT):
    """Files required to restore/run a customer release, never the developer repository.

    Format 1 backups retain their old build context so a 0.2.x physical backup remains
    restorable. Format 2 customer artifacts contain only deployment logic, migrations,
    workflows and operations documentation; the application is an immutable OCI image.
    """
    definition = release(root)
    legacy = definition.get('deployment_format', 1) < 2
    singles = []
    folders = ['supabase/migrations', 'n8n/workflows']
    if legacy:
        singles = ['Dockerfile', '.dockerignore', 'package.json', 'package-lock.json',
                   'next.config.ts', 'tsconfig.json', 'postcss.config.mjs', 'components.json']
        folders += ['src', 'public', 'deploy']
    else:
        singles = [
            'deploy/README_TR.md', 'deploy/VALIDATION.md', 'deploy/config.py',
            'deploy/manage.py', 'deploy/migrations.py', 'deploy/release.json',
            'deploy/scheduled-update.py',
        ]
        folders += ['deploy/vendor', 'deploy/systemd']
    files = [root / f for f in singles if (root / f).is_file()]
    for folder in folders:
        for p in (root / folder).rglob('*'):
            if p.is_file() and not any(part.startswith('.') or part == '__pycache__'
                                       for part in p.relative_to(root).parts):
                if p.is_symlink():
                    raise ValueError('Release must not contain symlinks: ' + str(p))
                files.append(p)
    return sorted(files)


def fingerprint(root=ROOT):
    h = hashlib.sha256()
    for p in source_files(root):
        h.update(str(p.relative_to(root)).encode() + b'\0' + p.read_bytes() + b'\0')
    return h.hexdigest()


def jwt(secret, role):
    enc = lambda b: base64.urlsafe_b64encode(b).decode().rstrip('=')
    now = int(time.time())
    data = enc(b'{"alg":"HS256","typ":"JWT"}') + '.' + enc(json.dumps({
        'role': role, 'iss': 'supabase', 'iat': now, 'exp': now + 10 * 365 * 86400
    }, separators=(',', ':')).encode())
    return data + '.' + enc(hmac.new(secret.encode(), data.encode(), hashlib.sha256).digest())


def new_settings(domain, api_domain, webhook_domain, email, password, local=False):
    cfg = dict(project='bdd-support', app_domain=domain, api_domain=api_domain,
               webhook_domain=webhook_domain, admin_email=email, admin_password=password,
               timezone='Europe/Amsterdam', local=local, whatsapp_access_token='',
               whatsapp_phone_number_id='', whatsapp_api_version='', workflows_enabled=False)
    for key, size in [('postgres_password', 32), ('jwt_secret', 32), ('n8n_encryption_key', 32),
                      ('realtime_secret', 64), ('realtime_db_key', 16), ('verify_token', 32)]:
        cfg[key] = secrets.token_hex(size) if key != 'realtime_db_key' else secrets.token_hex(8)
    cfg['anon_key'] = jwt(cfg['jwt_secret'], 'anon')
    cfg['service_key'] = jwt(cfg['jwt_secret'], 'service_role')
    validate(cfg)
    return cfg


def validate(c):
    if not re.fullmatch(r'[a-z][a-z0-9-]{2,40}', c['project']):
        raise ValueError('Invalid Compose project name')
    for k in ['app_domain', 'api_domain', 'webhook_domain']:
        if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9.-]*(?::[0-9]{1,5})?', c[k]):
            raise ValueError('Invalid hostname: ' + k)
    if len({c[k] for k in ['app_domain', 'api_domain', 'webhook_domain']}) != 3:
        raise ValueError('App, API and webhook addresses must be different')
    if not c['local'] and any(':' in c[k] or c[k].endswith('.localhost') or c[k] == 'localhost'
                              for k in ['app_domain', 'api_domain', 'webhook_domain']):
        raise ValueError('Production requires three DNS hostnames without ports')
    if len(c['admin_password']) < 12 or '@' not in c['admin_email']:
        raise ValueError('Admin email and a password of at least 12 characters required')
    # Passwords are inserted in PostgreSQL connection URIs; generated hex is safe.
    for key, minimum in [('postgres_password', 32), ('jwt_secret', 32), ('n8n_encryption_key', 32)]:
        if not re.fullmatch(r'[a-f0-9]{%d,}' % minimum, c[key]):
            raise ValueError('Invalid generated secret: ' + key)
    if c['workflows_enabled']:
        if not c['whatsapp_access_token'] or not c['whatsapp_phone_number_id'].isdigit():
            raise ValueError('WhatsApp token and numeric phone number ID are required before activation')
        if not re.fullmatch(r'v[0-9]+\.[0-9]+', c['whatsapp_api_version']):
            raise ValueError('Set the WhatsApp API version supported by your Meta account')


def public_urls(c):
    protocol = 'http' if c['local'] else 'https'
    return [protocol + '://' + c[k] for k in ['app_domain', 'api_domain', 'webhook_domain']]


def kong_config(c):
    cors = {'name': 'cors'}
    auth = [{'name': 'key-auth', 'config': {'hide_credentials': False}},
            {'name': 'acl', 'config': {'hide_groups_header': True, 'allow': ['anon', 'admin']}}]
    def route(name, upstream, path, secure=True, protocol=None):
        s = {'name': name, 'url': upstream,
             'routes': [{'name': name, 'strip_path': True, 'paths': [path]}],
             'plugins': [cors] + (auth if secure else [])}
        if protocol:
            s['protocol'] = protocol
        return s
    return {
        '_format_version': '3.0', '_transform': True,
        'consumers': [
            {'username': 'anon', 'keyauth_credentials': [{'key': c['anon_key']}]},
            {'username': 'service_role', 'keyauth_credentials': [{'key': c['service_key']}]}],
        'acls': [{'consumer': 'anon', 'group': 'anon'}, {'consumer': 'service_role', 'group': 'admin'}],
        'services': [
            route('auth', 'http://auth:9999/', '/auth/v1/'),
            route('verify', 'http://auth:9999/verify', '/auth/v1/verify', False),
            route('callback', 'http://auth:9999/callback', '/auth/v1/callback', False),
            route('rest', 'http://rest:3000/', '/rest/v1/'),
            route('realtime', 'http://realtime-dev.supabase-realtime:4000/socket', '/realtime/v1/', True, 'ws'),
            route('realtime-api', 'http://realtime-dev.supabase-realtime:4000/api', '/realtime/v1/api'),
            # Storage validates bearer tokens and signed URL tokens itself.
            route('storage', 'http://storage:5000/', '/storage/v1/', False)]}


def caddy_config(c):
    app, api, webhook = public_urls(c)
    # Expose only production webhooks. The n8n editor is loopback-only.
    return f'''{{
    admin off
}}
{app} {{
    encode gzip
    reverse_proxy app:3000
}}
{api} {{
    reverse_proxy gateway:8000
}}
{webhook} {{
    handle /webhook/* {{
        reverse_proxy n8n:5678
    }}
    handle {{
        respond "Not found" 404
    }}
}}
'''


def compose(c, state, root=ROOT):
    validate(c)
    r = release(root)
    images = r['images']
    state = Path(state).resolve()
    app_url, api_url, webhook_url = public_urls(c)
    data = state / 'data'
    config = state / 'config'
    vendor = root / 'deploy/vendor/supabase/db'
    password = c['postgres_password']
    uri = lambda user: f'postgres://{user}:{password}@db:5432/postgres'
    healthy = lambda *names: {n: {'condition': 'service_healthy'} for n in names}
    def service(image, env=None, **kw):
        return dict(image=image, restart='unless-stopped', environment=env or {},
                    logging={'driver': 'json-file', 'options': {'max-size': '10m', 'max-file': '3'}}, **kw)
    def health(cmd, start='20s'):
        return dict(test=cmd, interval='10s', timeout='5s', retries=18, start_period=start)
    db_ready_sql = (
        "SELECT EXISTS (SELECT 1 FROM pg_authid WHERE rolname = 'supabase_storage_admin' "
        "AND rolpassword IS NOT NULL) AND EXISTS (SELECT 1 FROM pg_authid WHERE rolname = "
        "'supabase_auth_admin' AND rolpassword IS NOT NULL) AND EXISTS (SELECT 1 FROM "
        "pg_authid WHERE rolname = 'authenticator' AND rolpassword IS NOT NULL) AND EXISTS "
        "(SELECT 1 FROM pg_namespace WHERE nspname = '_realtime') AND EXISTS (SELECT 1 FROM "
        "pg_database WHERE datname = '_supabase');"
    )
    services = {}
    services['db'] = service(images['db'], {
        'POSTGRES_HOST': '/var/run/postgresql', 'PGPORT': '5432', 'POSTGRES_PORT': '5432',
        'POSTGRES_DB': 'postgres', 'PGDATABASE': 'postgres', 'POSTGRES_PASSWORD': password,
        'PGPASSWORD': password, 'JWT_EXP': '3600'},
        command=['postgres', '-c', 'config_file=/etc/postgresql/postgresql.conf', '-c', 'log_min_messages=warning'],
        volumes=[f'{data}/db:/var/lib/postgresql/data', f'{data}/db-config:/etc/postgresql-custom',
                 f'{vendor}/roles.sql:/docker-entrypoint-initdb.d/init-scripts/99-roles.sql:ro',
                 f'{vendor}/jwt.sql:/docker-entrypoint-initdb.d/init-scripts/99-jwt.sql:ro',
                 f'{vendor}/_supabase.sql:/docker-entrypoint-initdb.d/migrations/97-_supabase.sql:ro',
                 f'{vendor}/auth-ownership.sql:/docker-entrypoint-initdb.d/migrations/98-auth-ownership.sql:ro',
                 f'{vendor}/realtime.sql:/docker-entrypoint-initdb.d/migrations/99-realtime.sql:ro'],
        healthcheck=health(['CMD-SHELL',
                            f'psql -X -U postgres -d postgres -tAc "{db_ready_sql}" | grep -qx t']))
    services['auth'] = service(images['auth'], {
        'GOTRUE_API_HOST': '0.0.0.0', 'GOTRUE_API_PORT': '9999', 'API_EXTERNAL_URL': api_url + '/auth/v1',
        'GOTRUE_DB_DRIVER': 'postgres', 'GOTRUE_DB_DATABASE_URL': uri('supabase_auth_admin'),
        'GOTRUE_SITE_URL': app_url, 'GOTRUE_URI_ALLOW_LIST': app_url + '/**',
        'GOTRUE_DISABLE_SIGNUP': 'true', 'GOTRUE_JWT_SECRET': c['jwt_secret'],
        'GOTRUE_JWT_ADMIN_ROLES': 'service_role', 'GOTRUE_JWT_AUD': 'authenticated',
        'GOTRUE_JWT_DEFAULT_GROUP_NAME': 'authenticated', 'GOTRUE_JWT_EXP': '3600',
        'GOTRUE_EXTERNAL_EMAIL_ENABLED': 'true', 'GOTRUE_MAILER_AUTOCONFIRM': 'true',
        'GOTRUE_EXTERNAL_ANONYMOUS_USERS_ENABLED': 'false', 'GOTRUE_EXTERNAL_PHONE_ENABLED': 'false'},
        depends_on=healthy('db'), healthcheck=health(['CMD', 'wget', '-q', '--spider', 'http://localhost:9999/health']))
    services['rest'] = service(images['rest'], {
        'PGRST_DB_URI': uri('authenticator'), 'PGRST_DB_SCHEMAS': 'public', 'PGRST_DB_ANON_ROLE': 'anon',
        'PGRST_JWT_SECRET': c['jwt_secret'], 'PGRST_DB_USE_LEGACY_GUCS': 'false',
        'PGRST_ADMIN_SERVER_PORT': '3001', 'PGRST_ADMIN_SERVER_HOST': 'localhost'},
        depends_on=healthy('db'), healthcheck=health(['CMD', 'postgrest', '--ready']))
    services['realtime'] = service(images['realtime'], {
        'PORT': '4000', 'DB_HOST': 'db', 'DB_PORT': '5432', 'DB_USER': 'supabase_admin',
        'DB_PASSWORD': password, 'DB_NAME': 'postgres', 'DB_AFTER_CONNECT_QUERY': 'SET search_path TO _realtime',
        'DB_ENC_KEY': c['realtime_db_key'], 'API_JWT_SECRET': c['jwt_secret'],
        'SECRET_KEY_BASE': c['realtime_secret'], 'METRICS_JWT_SECRET': c['jwt_secret'],
        'ERL_AFLAGS': '-proto_dist inet_tcp', 'DNS_NODES': "''", 'RLIMIT_NOFILE': '10000',
        'APP_NAME': 'realtime', 'SEED_SELF_HOST': 'true', 'RUN_JANITOR': 'true',
        'DISABLE_HEALTHCHECK_LOGGING': 'true'},
        hostname='realtime-dev.supabase-realtime',
        networks={'default': {'aliases': ['realtime-dev.supabase-realtime']}},
        depends_on=healthy('db'),
        healthcheck=health(['CMD-SHELL', 'curl -sf -H "Authorization: Bearer ' + c['anon_key'] + '" http://localhost:4000/api/tenants/realtime-dev/health'], '40s'))
    services['storage'] = service(images['storage'], {
        'ANON_KEY': c['anon_key'], 'SERVICE_KEY': c['service_key'], 'POSTGREST_URL': 'http://rest:3000',
        'AUTH_JWT_SECRET': c['jwt_secret'], 'DATABASE_URL': uri('supabase_storage_admin'),
        'STORAGE_PUBLIC_URL': api_url, 'REQUEST_ALLOW_X_FORWARDED_PATH': 'true',
        'FILE_SIZE_LIMIT': '52428800', 'STORAGE_BACKEND': 'file', 'GLOBAL_S3_BUCKET': 'stub',
        'FILE_STORAGE_BACKEND_PATH': '/var/lib/storage', 'TENANT_ID': 'stub', 'REGION': 'local',
        'ENABLE_IMAGE_TRANSFORMATION': 'false'},
        depends_on=healthy('db', 'rest'), volumes=[f'{data}/storage:/var/lib/storage'],
        healthcheck=health(['CMD', 'wget', '-q', '--spider', 'http://127.0.0.1:5000/status']))
    services['gateway'] = service(images['gateway'], {
        'KONG_DATABASE': 'off', 'KONG_DECLARATIVE_CONFIG': '/config/kong.json',
        'KONG_DNS_ORDER': 'LAST,A,CNAME', 'KONG_PLUGINS': 'cors,key-auth,acl',
        'KONG_PROXY_LISTEN': '0.0.0.0:8000', 'KONG_ADMIN_LISTEN': 'off',
        'KONG_NGINX_PROXY_PROXY_BUFFER_SIZE': '160k', 'KONG_NGINX_PROXY_PROXY_BUFFERS': '64 160k'},
        depends_on=healthy('auth', 'rest', 'realtime', 'storage'),
        volumes=[f'{config}/kong.json:/config/kong.json:ro'], healthcheck=health(['CMD', 'kong', 'health']))
    services['n8n'] = service(images['n8n'], {
        'N8N_HOST': urlparse(webhook_url).hostname, 'N8N_PORT': '5678', 'N8N_PROTOCOL': 'http' if c['local'] else 'https',
        'N8N_WEBHOOK_URL': webhook_url + '/', 'N8N_PROXY_HOPS': '1', 'N8N_ENCRYPTION_KEY': c['n8n_encryption_key'],
        'N8N_SECURE_COOKIE': 'false' if c['local'] else 'true',
        'N8N_BLOCK_ENV_ACCESS_IN_NODE': 'false', 'GENERIC_TIMEZONE': c['timezone'], 'TZ': c['timezone'],
        'N8N_DIAGNOSTICS_ENABLED': 'false', 'N8N_VERSION_NOTIFICATIONS_ENABLED': 'false',
        'N8N_PERSONALIZATION_ENABLED': 'false', 'EXECUTIONS_DATA_PRUNE': 'true',
        'EXECUTIONS_DATA_MAX_AGE': '24', 'EXECUTIONS_DATA_PRUNE_MAX_COUNT': '5000',
        'EXECUTIONS_DATA_SAVE_ON_SUCCESS': 'all', 'EXECUTIONS_DATA_SAVE_ON_ERROR': 'all',
        'EXECUTIONS_DATA_SAVE_MANUAL_EXECUTIONS': 'true',
        'N8N_GRACEFUL_SHUTDOWN_TIMEOUT': '120',
        'SUPABASE_URL': 'http://gateway:8000', 'SUPABASE_SERVICE_ROLE_KEY': c['service_key'],
        'WHATSAPP_ACCESS_TOKEN': c['whatsapp_access_token'], 'WHATSAPP_PHONE_NUMBER_ID': c['whatsapp_phone_number_id'],
        'WHATSAPP_API_VERSION': c['whatsapp_api_version'], 'WHATSAPP_WEBHOOK_VERIFY_TOKEN': c['verify_token']},
        depends_on=healthy('gateway'), stop_grace_period='150s',
        ports=['127.0.0.1:5678:5678'],
        volumes=[f'{data}/n8n:/home/node/.n8n', f'{root}/n8n/workflows:/workflows:ro'],
        healthcheck=health(['CMD', 'node', '-e', "fetch('http://localhost:5678/healthz/readiness').then(r=>{if(!r.ok)process.exit(1)}).catch(()=>process.exit(1))"], '60s'))
    services['app'] = service(images['app'], {
        'APP_PUBLIC_URL': app_url,
        'SUPABASE_PUBLIC_URL': api_url, 'SUPABASE_INTERNAL_URL': 'http://gateway:8000',
        'SUPABASE_ANON_KEY': c['anon_key'], 'SUPABASE_SERVICE_ROLE_KEY': c['service_key']},
        depends_on=healthy('gateway'),
        healthcheck=health(['CMD', 'node', '-e', "fetch('http://127.0.0.1:3000/login').then(r=>{if(!r.ok)process.exit(1)}).catch(()=>process.exit(1))"]))
    ports = ['80:80', '443:443', '443:443/udp']
    if c['local']:
        ports = ['127.0.0.1:8080:8080', '127.0.0.1:8081:8081', '127.0.0.1:8082:8082']
    services['proxy'] = service(images['proxy'], volumes=[f'{config}/Caddyfile:/etc/caddy/Caddyfile:ro',
        f'{data}/caddy:/data', f'{data}/caddy-config:/config'], ports=ports)
    # Compose performs dollar interpolation even in JSON input. All values here
    # are already rendered, so preserve literal dollars in customer secrets.
    def escape(value):
        if isinstance(value, str): return value.replace('$', '$$')
        if isinstance(value, list): return [escape(v) for v in value]
        if isinstance(value, dict): return {k: escape(v) for k, v in value.items()}
        return value
    return escape({'name': c['project'], 'services': services})

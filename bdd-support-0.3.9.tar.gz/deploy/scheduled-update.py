#!/usr/bin/env python3
"""Apply an operator-approved, already unpacked release in a maintenance window."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--state', required=True, type=Path)
parser.add_argument('--approved-release-file', required=True, type=Path)
args = parser.parse_args()
if not args.approved_release_file.exists():
    print('No approved release; nothing to do.')
    sys.exit(0)
release_path = Path(args.approved_release_file.read_text().strip()).resolve()
current = json.loads((args.state / 'current.json').read_text())
target = json.loads((release_path / 'deploy/release.json').read_text())
version = lambda s: tuple(int(x) for x in s.split('.'))
if version(target['version']) <= version(current['version']):
    print('No newer approved release; nothing to do.')
    sys.exit(0)
if not (release_path / 'RELEASE-MANIFEST.json').is_file():
    raise SystemExit('Only packaged releases may be scheduled')
# The target manager verifies manifest, makes a backup and rejects infrastructure changes.
subprocess.run([sys.executable, str(release_path / 'deploy/manage.py'), 'update',
                '--state', str(args.state.resolve())], check=True)

"""Transactional migrations with immutable checksums and a database-level lock."""
import hashlib
import re
from pathlib import Path


def inventory(folder):
    result = []
    seen = set()
    for p in sorted(Path(folder).glob('*.sql')):
        match = re.fullmatch(r'([0-9]+)_[a-zA-Z0-9_]+\.sql', p.name)
        if not match or int(match[1]) in seen:
            raise ValueError('Invalid/duplicate migration version: ' + p.name)
        seen.add(int(match[1]))
        result.append((int(match[1]), p.name, hashlib.sha256(p.read_bytes()).hexdigest(), p.read_text()))
    if not result:
        raise ValueError('No migrations found')
    return sorted(result)


def migration_sql(folder):
    migrations = inventory(folder)
    sql = [r'\set ON_ERROR_STOP on', 'BEGIN;', "SELECT pg_advisory_xact_lock(781930241);",
           "DO $$ BEGIN IF to_regclass('public.profiles') IS NOT NULL AND "
           "to_regclass('app_deploy.migrations') IS NULL THEN RAISE EXCEPTION "
           "'Existing unmanaged database: explicit migration baseline audit required'; END IF; END $$;",
           'CREATE SCHEMA IF NOT EXISTS app_deploy;',
           'REVOKE ALL ON SCHEMA app_deploy FROM PUBLIC, anon, authenticated;',
           'CREATE TABLE IF NOT EXISTS app_deploy.migrations ('
           'version bigint PRIMARY KEY, name text NOT NULL, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now());',
           'CREATE TEMP TABLE expected_migrations(version bigint, name text, checksum text) ON COMMIT DROP;']
    for version, name, sha, _ in migrations:
        sql.append(f"INSERT INTO expected_migrations VALUES ({version}, '{name}', '{sha}');")
    sql += ["DO $$ BEGIN IF EXISTS (SELECT 1 FROM app_deploy.migrations a LEFT JOIN expected_migrations e USING(version) "
            "WHERE e.version IS NULL OR a.name <> e.name OR a.checksum <> e.checksum) THEN "
            "RAISE EXCEPTION 'Applied migration changed or removed; restore original files and add a new migration'; END IF; "
            "IF EXISTS (SELECT 1 FROM expected_migrations e WHERE e.version < (SELECT max(version) FROM app_deploy.migrations) "
            "AND NOT EXISTS (SELECT 1 FROM app_deploy.migrations a WHERE a.version=e.version)) THEN "
            "RAISE EXCEPTION 'Out-of-order migration: use a higher version'; END IF; END $$;",
            # Supabase local dev normally supplies these default grants. Self-hosted must be explicit.
            'GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;',
            'ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon, authenticated, service_role;',
            'ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon, authenticated, service_role;',
            'ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon, authenticated, service_role;']
    for version, name, sha, content in migrations:
        sql += [f"SELECT NOT EXISTS (SELECT 1 FROM app_deploy.migrations WHERE version={version}) AS apply_next \\gset",
                r'\if :apply_next', fr'\echo Applying {name}', content,
                f"INSERT INTO app_deploy.migrations(version,name,checksum) VALUES ({version},'{name}','{sha}');", r'\endif']
    sql += ["NOTIFY pgrst, 'reload schema';", 'COMMIT;']
    return '\n'.join(sql) + '\n'

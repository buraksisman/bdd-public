#!/usr/bin/env python3
"""BDD customer deployment. Python stdlib + Docker Compose v2; no host Node/npm required."""
import argparse
import contextlib
import fcntl
import getpass
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import time

from config import (ROOT, CORE, WORKFLOWS, compose, caddy_config, kong_config, release,
                    source_files, fingerprint, new_settings, validate, public_urls)
from migrations import migration_sql, inventory


DEFAULT_BACKUP_RETENTION = 7
MIN_PRODUCTION_FREE_BYTES = 10 * 1024 * 1024 * 1024
DIGEST_REF = re.compile(r'^.+@sha256:[0-9a-f]{64}$')


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, value, mode=0o600):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    tmp.chmod(mode)
    tmp.replace(path)


def run(args, *, input=None, capture=False, env=None):
    # No shell execution and no secret values printed as command arguments.
    return subprocess.run([str(a) for a in args], input=input, check=True, text=True,
                          stdout=subprocess.PIPE if capture else None, env=env)


def dc(state, *args, candidate=False, **kw):
    filename = 'candidate.json' if candidate else 'compose.json'
    project = json.loads((state / filename).read_text())['name']
    return run(['docker', 'compose', '--project-name', project, '-f', state / filename, *args], **kw)


@contextlib.contextmanager
def locked(state):
    state.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (state / '.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError('Another deployment command is running')
        yield


def settings(state):
    c = json.loads((state / 'settings.json').read_text())
    validate(c)
    return c


def docker_check(production=False, require_buildx=False):
    if not shutil.which('docker'):
        raise ValueError('Docker CLI not found; install Docker Engine and Compose v2')
    try:
        context = run(['docker', 'context', 'show'], capture=True).stdout.strip()
        if production and ('desktop' in context.lower() or context == 'desktop-linux'):
            raise ValueError(
                f'Docker context {context!r} is a Docker Desktop context; production requires '
                'the Linux Docker Engine context/socket (usually default and /var/run/docker.sock)'
            )
        server = run(['docker', 'info', '--format', '{{.ServerVersion}}'], capture=True).stdout.strip()
        if not server:
            raise ValueError('Docker Engine returned no server version')
    except subprocess.CalledProcessError as exc:
        raise ValueError(
            'Docker Engine is unreachable. Check `docker context show`, `docker context inspect`, '
            'the daemon status, and access to /var/run/docker.sock'
        ) from exc
    try:
        version = run(['docker', 'compose', 'version', '--short'], capture=True).stdout.strip().lstrip('v')
        parts = version.split('.')
        if len(parts) < 2 or tuple(int(p) for p in parts[:2]) < (2, 24):
            raise ValueError('Docker Compose >= 2.24 is required; found ' + version)
    except (subprocess.CalledProcessError, ValueError) as exc:
        if isinstance(exc, ValueError) and 'found' in str(exc):
            raise
        raise ValueError('Docker Compose v2.24+ is required (`docker compose version`)') from exc
    if require_buildx:
        try:
            run(['docker', 'buildx', 'version'], capture=True)
        except subprocess.CalledProcessError as exc:
            raise ValueError('Docker buildx is required (`docker buildx version`)') from exc
    return context, server, version


def installation_has_data(state):
    data = state / 'data'
    return data.exists() and any(p.is_file() or any(p.iterdir()) for p in data.iterdir())


def check_port_available(port, socktype=socket.SOCK_STREAM):
    sock = socket.socket(socket.AF_INET, socktype)
    try:
        sock.bind(('0.0.0.0', port))
    except OSError as exc:
        protocol = 'UDP' if socktype == socket.SOCK_DGRAM else 'TCP'
        raise ValueError(
            f'{protocol} port {port} is unavailable ({exc}); stop the conflicting service '
            'or place BDD Support behind the approved host proxy before install'
        ) from exc
    finally:
        sock.close()


def install_preflight(state, c):
    context, server, compose_version = docker_check(
        production=not c['local'], require_buildx=False)
    probe = state / '.preflight-write'
    try:
        probe.write_text('ok')
        probe.unlink()
    except OSError as exc:
        raise ValueError(f'State directory is not writable: {state} ({exc})') from exc
    free = shutil.disk_usage(state).free
    minimum = 2 * 1024**3 if c['local'] else MIN_PRODUCTION_FREE_BYTES
    if free < minimum:
        raise ValueError(
            f'Insufficient free disk space at {state}: {free // 1024**3} GiB available; '
            f'at least {minimum // 1024**3} GiB required'
        )
    if not c['local']:
        architecture = {'x86_64': 'amd64', 'aarch64': 'arm64'}.get(
            platform.machine(), platform.machine())
        if architecture not in release().get('supported_architectures', []):
            raise ValueError(
                f'Unsupported production architecture {architecture}; this release supports '
                + ', '.join(release().get('supported_architectures', []))
            )
        for port, kind in [(80, socket.SOCK_STREAM), (443, socket.SOCK_STREAM),
                           (443, socket.SOCK_DGRAM)]:
            check_port_available(port, kind)
        for key in ['app_domain', 'api_domain', 'webhook_domain']:
            try:
                addresses = socket.getaddrinfo(c[key], 443, type=socket.SOCK_STREAM)
            except socket.gaierror as exc:
                raise ValueError(
                    f'DNS does not resolve for {key}={c[key]}; create the record and verify '
                    f'with `getent hosts {c[key]}`'
                ) from exc
            if not addresses:
                raise ValueError(f'DNS returned no address for {key}={c[key]}')
    print('Preflight OK: Docker Engine', server, '| context', context,
          '| Compose', compose_version, '| free disk', free // 1024**3, 'GiB')


def render(state, c, candidate=False):
    write_json(state / ('candidate.json' if candidate else 'compose.json'), compose(c, state))
    if not candidate:
        config = state / 'config'
        config.mkdir(exist_ok=True)
        # Files mounted in unprivileged containers must be readable there.
        # The surrounding host state directory remains private (0700).
        write_json(config / 'kong.json', kong_config(c), 0o644)
        (config / 'Caddyfile').write_text(caddy_config(c))
        (config / 'Caddyfile').chmod(0o644)


def pack(destination, root=ROOT):
    destination = Path(destination).resolve()
    if destination.is_relative_to(root / 'deploy') and not any(
            part.startswith('.') for part in destination.relative_to(root / 'deploy').parts):
        raise ValueError('Place release archives outside deploy/')
    definition = release(root)
    if definition.get('deployment_format', 1) >= 2 and not definition.get('finalized'):
        raise ValueError('Source tree is not a customer artifact; finalize OCI image digests first')
    if (definition.get('deployment_format', 1) >= 2
            and not definition.get('development_artifact')
            and not all(DIGEST_REF.fullmatch(ref) for ref in definition['images'].values())):
        raise ValueError('Customer release contains an unpinned OCI image')
    files = source_files(root)
    manifest = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    with tarfile.open(destination, 'w:gz') as tar:
        for p in files:
            tar.add(p, arcname=str(p.relative_to(root)), recursive=False)
        import io
        data = json.dumps(manifest, sort_keys=True).encode()
        info = tarfile.TarInfo('RELEASE-MANIFEST.json')
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
    destination.chmod(0o600)
    return sha256_file(destination)


def verify_release(root=ROOT):
    path = root / 'RELEASE-MANIFEST.json'
    if path.exists():
        expected = json.loads(path.read_text())
        actual = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files(root)}
        if actual != expected:
            raise ValueError('Release manifest mismatch; do not edit an extracted release')


def require_runnable_release(c, root=ROOT):
    definition = release(root)
    if definition.get('deployment_format', 1) < 2:
        return
    if not definition.get('finalized'):
        raise ValueError('This is a developer source tree, not a finalized customer release')
    if definition.get('development_artifact') and not c['local']:
        raise ValueError('Development release artifacts may only be used with --local settings')
    if not definition.get('development_artifact') and not all(
            DIGEST_REF.fullmatch(ref) for ref in definition['images'].values()):
        raise ValueError('Finalized customer release must pin every runtime image by digest')


def safe_extract(archive, destination):
    destination = Path(destination).resolve()
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar.getmembers():
            target = (destination / member.name).resolve()
            if not target.is_relative_to(destination) or not (member.isfile() or member.isdir()):
                raise ValueError('Unsafe release archive member')
        # Only validated regular files/directories; no links, traversal or devices.
        for member in tar.getmembers():
            target = destination / member.name
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with tar.extractfile(member) as src, target.open('wb') as dst:
                    shutil.copyfileobj(src, dst)


def prepare(state, c):
    verify_release()
    require_runnable_release(c)
    inventory(ROOT / 'supabase/migrations')
    render(state, c, candidate=True)
    dc(state, 'config', '--quiet', candidate=True)
    # Pull immutable images before downtime. The customer host never builds source code.
    # Local integration runs build a disposable app image in the runner; that image
    # is intentionally not present in a registry, so only vendor images are pulled.
    local_app = release().get('images', {}).get('app', '').startswith('bdd-support-app:')
    if c.get('local') or local_app:
        dc(state, 'pull', '--policy', 'always', 'db', 'auth', 'rest', 'realtime',
           'storage', 'gateway', 'n8n', 'proxy', candidate=True)
    else:
        dc(state, 'pull', '--policy', 'always', candidate=True)


def init_dirs(state):
    for name in ['db', 'db-config', 'storage', 'n8n', 'caddy', 'caddy-config']:
        (state / 'data' / name).mkdir(parents=True, exist_ok=True)
    # Bind mounts hide the image's files (unlike Docker's empty named-volume
    # copy-up). Seed defaults only while conf.d is absent. Later update/configure
    # runs preserve the complete customer configuration directory.
    run(['docker', 'run', '--rm', '--network', 'none', '--user', '0:0',
         '--entrypoint', '/bin/sh',
         '--mount', f'type=bind,src={state / "data/db-config"},dst=/target',
         release()['images']['db'], '-ec',
         'if [ ! -d /target/conf.d ]; then '
         '  cp -a /etc/postgresql-custom/. /target/; '
         'fi; '
         'test -d /target/conf.d; '
         'chown -R postgres:postgres /target'])
    run(['docker', 'run', '--rm', '--network', 'none',
         '--mount', f'type=bind,src={state / "data/n8n"},dst=/data', release()['images']['backup'],
         'chown', '1000:1000', '/data'])


def migrate(state):
    # One connection, one transaction, advisory lock. No partial batch commits.
    dc(state, 'exec', '-T', 'db', 'psql', '-X', '-v', 'ON_ERROR_STOP=1', '-U', 'postgres', '-d', 'postgres',
       input=migration_sql(ROOT / 'supabase/migrations'))


def workflows(state, c):
    # Dedicated customer n8n. Fixed IDs update the same managed workflows on every release.
    for name in WORKFLOWS:
        path = ROOT / 'n8n/workflows' / (name + '.json')
        workflow_id = json.loads(path.read_text())['id']
        dc(state, 'run', '--rm', '--no-deps', '-T', 'n8n', 'import:workflow', '--input=/workflows/' + path.name)
        # Import deactivates this workflow by default in the pinned n8n version.
        if c['workflows_enabled']:
            dc(state, 'run', '--rm', '--no-deps', '-T', 'n8n', 'publish:workflow', '--id=' + workflow_id)


def n8n_query(state, query, parameters=()):
    database = state / 'data/n8n/database.sqlite'
    try:
        with contextlib.closing(sqlite3.connect(
                f'file:{database}?mode=ro', uri=True, timeout=3)) as connection:
            return connection.execute(query, parameters).fetchall()
    except sqlite3.Error as exc:
        raise ValueError(
            f'Cannot inspect n8n runtime database at {database}; run deployment commands '
            'with the same administrative account used for install'
        ) from exc


def wait_for_n8n_row(state, query, parameters=(), timeout=45):
    deadline = time.monotonic() + timeout
    last_error = None
    while time.monotonic() < deadline:
        try:
            rows = n8n_query(state, query, parameters)
            if rows:
                return rows[0]
        except ValueError as exc:
            last_error = exc
        time.sleep(1)
    detail = f'; last error: {last_error}' if last_error else ''
    raise ValueError(f'n8n runtime smoke check timed out after {timeout}s{detail}')


def verify_managed_workflows(state, c):
    definitions = {
        name: json.loads((ROOT / 'n8n/workflows' / (name + '.json')).read_text())
        for name in WORKFLOWS
    }
    for name, workflow in definitions.items():
        row = wait_for_n8n_row(
            state,
            'SELECT active, activeVersionId FROM workflow_entity WHERE id = ?',
            (workflow['id'],),
        )
        active, published_version = bool(row[0]), row[1]
        if c['workflows_enabled'] and (not active or not published_version):
            raise ValueError(f'Managed workflow was not published: {workflow["name"]}')
        if not c['workflows_enabled'] and active:
            raise ValueError(f'Managed workflow is active while workflows_enabled=false: {workflow["name"]}')
    if not c['workflows_enabled']:
        print('n8n smoke check: managed workflows imported and disabled as configured')
        return
    for name, method in [('whatsapp-verify', 'GET'), ('whatsapp-inbound', 'POST')]:
        workflow = definitions[name]
        wait_for_n8n_row(
            state,
            'SELECT webhookPath FROM webhook_entity WHERE workflowId = ? AND method = ?',
            (workflow['id'], method),
        )
    outbound = definitions['whatsapp-outbound']
    status = wait_for_n8n_row(
        state,
        'SELECT status FROM execution_entity WHERE workflowId = ? AND mode = ? '
        'ORDER BY id DESC LIMIT 1',
        (outbound['id'], 'trigger'),
    )[0]
    print('n8n smoke check: workflows published, GET/POST webhooks registered, '
          'Schedule Trigger executed with status', status)


def verify_runtime_configuration(state, c):
    script = (
        "process.stdout.write(JSON.stringify({phone:process.env.WHATSAPP_PHONE_NUMBER_ID||'',"
        "api:process.env.WHATSAPP_API_VERSION||'',enabled:process.env.WHATSAPP_ACCESS_TOKEN?true:false,"
        "webhook:process.env.N8N_WEBHOOK_URL||''}))"
    )
    raw = dc(state, 'exec', '-T', 'n8n', 'node', '-e', script, capture=True).stdout
    actual = json.loads(raw)
    expected_webhook = public_urls(c)[2] + '/'
    if actual['phone'] != c['whatsapp_phone_number_id'] or actual['api'] != c['whatsapp_api_version']:
        raise ValueError('n8n runtime WhatsApp configuration differs from settings.json; '
                         'configure did not recreate the container with current settings')
    if actual['webhook'] != expected_webhook:
        raise ValueError('n8n runtime webhook URL differs from settings.json')
    if actual['enabled'] != bool(c['whatsapp_access_token']):
        raise ValueError('n8n runtime token presence differs from settings.json')
    print('Runtime configuration (no secrets):')
    print('  Active Phone Number ID:', c['whatsapp_phone_number_id'] or '(not configured)')
    print('  API version:', c['whatsapp_api_version'] or '(not configured)')
    print('  Workflows enabled:', str(bool(c['workflows_enabled'])).lower())
    print('  Webhook URL:', expected_webhook)


def bootstrap(state, c):
    env = dict(os.environ, BOOTSTRAP_ADMIN_EMAIL=c['admin_email'], BOOTSTRAP_ADMIN_PASSWORD=c['admin_password'])
    dc(state, 'run', '--rm', '--no-deps', '-T', '-e', 'BOOTSTRAP_ADMIN_EMAIL', '-e', 'BOOTSTRAP_ADMIN_PASSWORD',
       'app', 'node', '/app/deploy/bootstrap-admin.mjs', env=env)


def launch(state, c, initial=False):
    render(state, c)
    init_dirs(state)
    dc(state, 'up', '-d', '--wait', '--wait-timeout', '300', *CORE)
    migrate(state)
    if initial:
        bootstrap(state, c)
    workflows(state, c)
    dc(state, 'up', '-d', '--wait', '--wait-timeout', '300', 'app', 'n8n')
    verify_managed_workflows(state, c)
    verify_runtime_configuration(state, c)
    # Public entry points are opened only after migration/import and internal health checks.
    dc(state, 'up', '-d', 'proxy')
    dc(state, 'exec', '-T', 'proxy', 'caddy', 'validate', '--config', '/etc/caddy/Caddyfile')
    definition = release()
    record = dict(version=definition['version'], deployment_format=definition['deployment_format'],
                  database_schema_version=definition.get('database_schema_version'),
                  source_commit=definition.get('source_commit'), fingerprint=fingerprint(),
                  release=str(ROOT), images=definition['images'],
                  deployed_at=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    write_json(state / 'current.json', record)
    write_json(state / 'deployed-settings.json', c)
    (state / 'FAILED').unlink(missing_ok=True)
    print('Deployment complete:', record['version'], public_urls(c)[0])
    if not c['workflows_enabled']:
        print('WhatsApp workflows are imported but disabled. Set Meta settings and run configure.')


def stop(state):
    # Stop ingress first, then producers, then database. No volume deletion.
    dc(state, 'stop', 'proxy')
    dc(state, 'stop', 'app', 'n8n')
    dc(state, 'stop')


def backup_stopped(state):
    current = json.loads((state / 'current.json').read_text())
    old_root = Path(current['release'])
    if not old_root.is_dir() or fingerprint(old_root) != current['fingerprint']:
        raise ValueError('Installed release directory changed/missing; restore immutable release before backup')
    stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + '-' + str(time.time_ns() % 1000000000).zfill(9)
    folder = state / 'backups' / stamp
    folder.mkdir(parents=True, mode=0o700)
    image = current['images']['backup']
    run(['docker', 'run', '--rm', '--network', 'none',
         '--mount', f'type=bind,src={state},dst=/state,readonly',
         '--mount', f'type=bind,src={folder},dst=/backup', image,
         'tar', '-czpf', '/backup/state.tar.gz', '--exclude=./backups', '--exclude=./.lock',
         '--exclude=./candidate.json', '--exclude=./failed-first-install-*', '-C', '/state', '.'])
    sha = pack(folder / 'release.tar.gz', old_root)
    state_sha = sha256_file(folder / 'state.tar.gz')
    write_json(folder / 'backup.json', {'release': current, 'state_sha256': state_sha, 'release_sha256': sha})
    print('Consistent cold backup:', folder)
    return folder


def backup_folders(state):
    root = state / 'backups'
    if not root.exists():
        return []
    return sorted(p for p in root.iterdir() if p.is_dir() and (p / 'backup.json').is_file())


def prune_backups(state, keep=DEFAULT_BACKUP_RETENTION, apply=False):
    if keep < 1:
        raise ValueError('Backup retention must keep at least one backup')
    folders = backup_folders(state)
    remove = folders[:-keep] if len(folders) > keep else []
    if not remove:
        print(f'Backup retention: {len(folders)} backup(s), nothing to remove (keep {keep})')
        return []
    print('Backups selected by retention policy:')
    for path in remove:
        print(' ', path)
    if not apply:
        print('Dry run only; repeat with --apply to delete these exact backup folders')
        return remove
    for path in remove:
        shutil.rmtree(path)
    print(f'Backup retention applied: removed {len(remove)}, kept newest {keep}')
    return remove


def reset_failed_install(state):
    if (state / 'current.json').exists():
        raise ValueError('Successful installation exists; use update/restore, not reset-failed-install')
    if not (state / 'FAILED').exists() and not installation_has_data(state):
        raise ValueError('No failed or partial first installation was found')
    if (state / 'compose.json').exists():
        dc(state, 'stop')
    stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
    archive = state / ('failed-first-install-' + stamp)
    archive.mkdir(mode=0o700)
    if (state / 'data').exists():
        (state / 'data').replace(archive / 'data')
    if (state / 'FAILED').exists():
        (state / 'FAILED').replace(archive / 'FAILED')
    for generated in ['compose.json', 'candidate.json']:
        (state / generated).unlink(missing_ok=True)
    shutil.rmtree(state / 'config', ignore_errors=True)
    print('Partial first-install data archived:', archive)
    print('settings.json was preserved. Review the archived diagnostics, then run install again.')
    return archive


def cleanup_path(state, requested, apply=False):
    path = Path(requested).resolve()
    state = state.resolve()
    allowed_backup = path.parent == (state / 'backups').resolve() and (path / 'backup.json').is_file()
    allowed_failed = path.parent == state and path.name.startswith('failed-first-install-')
    if not (allowed_backup or allowed_failed) or not path.is_dir() or path.is_symlink():
        raise ValueError('Cleanup path must be one exact backup or failed-first-install-* directory under state')
    print('Cleanup candidate:', path)
    if not apply:
        print('Dry run only; repeat with --apply and the same exact --path to delete it')
        return
    shutil.rmtree(path)
    print('Deleted:', path)


def maintenance(state, action, resume_on_success=False):
    write_json(state / 'FAILED', {'phase': 'backup', 'message': 'Maintenance in progress'})
    stop(state)
    try:
        result = action()
    except Exception:
        # Never restart a half-upgraded application automatically.
        if not (state / 'FAILED').exists():
            write_json(state / 'FAILED', {'phase': 'upgrade', 'message': 'Maintenance failed'})
        # A failed final health check must not leave the public proxy accepting traffic.
        dc(state, 'stop', 'proxy', 'app', 'n8n')
        raise
    if resume_on_success:
        dc(state, 'up', '-d', '--wait', '--wait-timeout', '300')
        (state / 'FAILED').unlink(missing_ok=True)
    return result


def upgrade(state, c, allow_infra=False, configure=False):
    current = json.loads((state / 'current.json').read_text())
    new = release()
    current_format = current.get('deployment_format', 1)
    format_transition = current_format == 1 and new['deployment_format'] == 2
    if new['deployment_format'] != current_format and not format_transition:
        raise ValueError('Unsupported deployment format transition')
    version = lambda v: tuple(int(x) for x in v.split('.'))
    if version(current['version']) < version(new.get('minimum_upgrade_version', '0.0.0')):
        raise ValueError('Current version is older than this release supports; use an intermediate release')
    deployed = json.loads((state / 'deployed-settings.json').read_text())
    for key in ['project', 'postgres_password', 'jwt_secret', 'anon_key', 'service_key', 'n8n_encryption_key', 'realtime_db_key', 'realtime_secret']:
        if c[key] != deployed[key]:
            raise ValueError('Secret/project rotation needs a separate procedure: ' + key)
    if not configure:
        if version(new['version']) <= version(current['version']):
            raise ValueError('Update must have a higher release version; use configure for settings changes')
    elif current['fingerprint'] != fingerprint():
        raise ValueError('configure must run from the installed immutable release')
    equivalent_db = current['images']['db'] == new.get('source_images', {}).get('db')
    if current['images']['db'] != new['images']['db'] and not (format_transition and equivalent_db):
        raise ValueError('PostgreSQL image changes require a separately tested database upgrade procedure')
    infra_changes = [
        k for k, value in current['images'].items()
        if k not in ['node', 'app'] and new['images'].get(k) != value
        and not (format_transition and new.get('source_images', {}).get(k) == value)
    ]
    if infra_changes and not allow_infra:
        raise ValueError('Infrastructure image changes require --allow-infrastructure-update: ' + ', '.join(infra_changes))
    prepare(state, c)
    def apply():
        backup_stopped(state)
        write_json(state / 'FAILED', {'phase': 'upgrade', 'message': 'Applying release'})
        launch(state, c)
    maintenance(state, apply)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['init', 'install', 'update', 'configure', 'backup',
        'restore', 'start', 'resume-previous', 'stop', 'status', 'pack', 'validate',
        'reset-failed-install', 'prune-backups', 'cleanup'])
    parser.add_argument('--state', type=Path, default=ROOT / 'deploy/.state')
    parser.add_argument('--local', action='store_true', help='Loopback-only HTTP smoke-test environment')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--backup', type=Path)
    parser.add_argument('--allow-infrastructure-update', action='store_true')
    parser.add_argument('--keep-backups', type=int, default=DEFAULT_BACKUP_RETENTION)
    parser.add_argument('--path', type=Path, help='Exact backup/recovery directory for cleanup')
    parser.add_argument('--apply', action='store_true', help='Apply cleanup/pruning after dry-run review')
    args = parser.parse_args()
    state = args.state.resolve()
    if args.command == 'pack':
        if not args.output:
            parser.error('--output is required')
        print('SHA256:', pack(args.output))
        return
    if args.command == 'validate':
        verify_release()
        inventory(ROOT / 'supabase/migrations')
        for name in WORKFLOWS:
            json.loads((ROOT / 'n8n/workflows' / (name + '.json')).read_text())
        kind = 'customer artifact' if release().get('finalized') else 'developer source definition'
        print('Release sources validated:', release()['version'], kind, fingerprint()[:16])
        return
    with locked(state):
        if args.command == 'init':
            if (state / 'settings.json').exists():
                raise ValueError('Settings exist; edit them directly, then run configure')
            if args.local:
                hosts = ['localhost:8080', 'localhost:8081', 'localhost:8082']
            else:
                hosts = [input(label + ': ').strip() for label in ['Panel domain', 'Supabase API domain', 'Webhook domain']]
            c = new_settings(*hosts, input('Initial admin email: ').strip(), getpass.getpass('Initial admin password (12+ chars): '), args.local)
            write_json(state / 'settings.json', c)
            print('Settings created:', state / 'settings.json')
            return
        if args.command == 'prune-backups':
            prune_backups(state, args.keep_backups, args.apply)
            return
        if args.command == 'cleanup':
            if not args.path:
                parser.error('cleanup requires --path')
            cleanup_path(state, args.path, args.apply)
            return
        if args.command == 'reset-failed-install':
            c = settings(state)
            docker_check(production=not c['local'])
            reset_failed_install(state)
            return
        if args.command == 'restore':
            if not args.backup:
                parser.error('--backup is required')
            docker_check()
            restore(state, args.backup.resolve())
            return
        c = settings(state)
        if args.command == 'install':
            install_preflight(state, c)
        else:
            docker_check()
        if (state / 'FAILED').exists() and args.command in ['update', 'configure', 'backup']:
            raise ValueError('Unresolved maintenance failure: resume-previous is only allowed before mutation; otherwise restore the last backup')
        if args.command == 'install':
            if (state / 'current.json').exists():
                raise ValueError('Already installed; use update')
            if (state / 'FAILED').exists() or installation_has_data(state):
                raise ValueError(
                    'Partial first-install state detected; it will not be reused automatically. '
                    'Run `python3 deploy/manage.py reset-failed-install --state '
                    f'{state}` to archive data safely, then run install again'
                )
            prepare(state, c)
            try:
                launch(state, c, initial=True)
            except Exception as exc:
                write_json(state / 'FAILED', {'phase': 'initial_install',
                    'message': 'Initial install failed; archive partial data before retry',
                    'error_type': type(exc).__name__})
                if (state / 'compose.json').exists():
                    dc(state, 'stop', 'proxy', 'app', 'n8n')
                raise
        elif args.command in ['update', 'configure']:
            upgrade(state, c, args.allow_infrastructure_update, args.command == 'configure')
            prune_backups(state, args.keep_backups, apply=True)
        elif args.command == 'backup':
            maintenance(state, lambda: backup_stopped(state), resume_on_success=True)
            prune_backups(state, args.keep_backups, apply=True)
        elif args.command == 'stop':
            stop(state)
        elif args.command == 'resume-previous':
            failure = json.loads((state / 'FAILED').read_text())
            if failure.get('phase') != 'backup':
                raise ValueError('Release mutation already began; restore the last backup instead')
            dc(state, 'up', '-d', '--wait', '--wait-timeout', '300')
            (state / 'FAILED').unlink()
        elif args.command == 'start':
            if (state / 'FAILED').exists():
                raise ValueError('Previous maintenance failed; repair/update or restore before start')
            dc(state, 'up', '-d', '--wait', '--wait-timeout', '300')
        elif args.command == 'status':
            if (state / 'current.json').exists():
                print((state / 'current.json').read_text())
            dc(state, 'ps')


def restore(state, folder):
    # Restore only to an empty state directory: never delete a customer's live data.
    if any(p.name != '.lock' for p in state.iterdir()):
        raise ValueError('Restore requires an empty --state directory; stop old stack first')
    manifest = json.loads((folder / 'backup.json').read_text())
    for name, key in [('state.tar.gz', 'state_sha256'), ('release.tar.gz', 'release_sha256')]:
        if sha256_file(folder / name) != manifest[key]:
            raise ValueError('Backup checksum mismatch: ' + name)
    source = state / 'restored-release'
    source.mkdir()
    safe_extract(folder / 'release.tar.gz', source)
    # Physical DB backup includes symlinks owned by the database; extract only trusted backup.
    run(['docker', 'run', '--rm', '--network', 'none',
         '--mount', f'type=bind,src={folder},dst=/backup,readonly',
         '--mount', f'type=bind,src={state},dst=/state', manifest['release']['images']['backup'],
         'tar', '-xzpf', '/backup/state.tar.gz', '-C', '/state'])
    # Re-render paths using the exact old release's renderer. Never run new migrations on restore.
    code = '''import sys,json
from pathlib import Path
from config import compose,kong_config,caddy_config,fingerprint
from manage import write_json
s=Path(sys.argv[1]); c=json.loads((s/'deployed-settings.json').read_text())
write_json(s/'settings.json',c)
write_json(s/'compose.json',compose(c,s))
write_json(s/'config/kong.json',kong_config(c),0o644)
(s/'config/Caddyfile').write_text(caddy_config(c))
r=json.loads((s/'current.json').read_text()); r['release']=str(Path.cwd().parent); r['fingerprint']=fingerprint(); write_json(s/'current.json',r)
(s/'FAILED').unlink(missing_ok=True)
'''
    subprocess.run([sys.executable, '-c', code, str(state)], cwd=source / 'deploy', check=True)
    local_app = manifest['release'].get('images', {}).get('app', '').startswith('bdd-support-app:')
    if local_app:
        dc(state, 'pull', '--policy', 'always', 'db', 'auth', 'rest', 'realtime',
           'storage', 'gateway', 'n8n', 'proxy')
    elif manifest['release'].get('deployment_format', 1) < 2:
        dc(state, 'build', 'app')
    else:
        dc(state, 'pull', '--policy', 'always')
    dc(state, 'up', '-d', '--wait', '--wait-timeout', '300', *CORE, 'app', 'n8n')
    dc(state, 'up', '-d', 'proxy')
    print('Restored to:', state, '\nFuture commands must use:', source / 'deploy/manage.py')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        # Subprocess exceptions include command, but arguments never contain credentials.
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)

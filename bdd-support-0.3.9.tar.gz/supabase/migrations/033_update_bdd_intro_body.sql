-- Migration 033: Update bdd_intro template body to Meta-approved Utility wording
UPDATE whatsapp_templates
SET body_text = 'Merhaba. Talebiniz BDD Müşavirlik tarafından alınmıştır. Süreciniz hakkında bilgi vermek için sizinle iletişime geçiyoruz.'
WHERE name = 'bdd_intro' AND language = 'tr';

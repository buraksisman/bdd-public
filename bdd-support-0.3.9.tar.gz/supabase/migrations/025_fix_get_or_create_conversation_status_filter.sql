-- Migration 025: Fix get_or_create_conversation — remove status = 'open' filter
-- ─────────────────────────────────────────────────────────────────────────────
-- Migration 007 established that statuses ('active', 'waiting', etc.) are
-- agent-applied TAGS, not routing state. A new inbound message must always
-- land in the existing conversation, regardless of its current status.
--
-- Migrations 017 and 021 (phone-first architecture) accidentally reintroduced
-- "AND c.status = 'open'" in both the primary and fallback lookups. This
-- caused a new unassigned (pool) conversation to be created whenever a message
-- arrived after the agent had changed the status label away from 'open'.
--
-- Fix: drop the status filter from both lookup paths. Only create a new
-- conversation when there is genuinely no prior conversation for that phone.

CREATE OR REPLACE FUNCTION get_or_create_conversation(
  p_phone_number_id UUID
)
RETURNS TABLE(id UUID)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id          UUID;
  v_phone       TEXT;
  v_name        TEXT;
  v_customer_id UUID;
BEGIN
  -- 1. Primary lookup: most recent conversation for this phone (any status).
  SELECT c.id INTO v_id
  FROM conversations c
  WHERE c.phone_number_id = p_phone_number_id
  ORDER BY c.created_at DESC
  LIMIT 1;

  -- 2. Fallback: legacy conversations that predate migration 017 and have
  --    phone_number_id = NULL but do have the phone_number text snapshot.
  IF v_id IS NULL THEN
    SELECT cpn.phone_number, cpn.whatsapp_name, cpn.customer_id
    INTO v_phone, v_name, v_customer_id
    FROM customer_phone_numbers cpn
    WHERE cpn.id = p_phone_number_id;

    SELECT c.id INTO v_id
    FROM conversations c
    WHERE c.phone_number = v_phone
      AND c.phone_number_id IS NULL
    ORDER BY c.created_at DESC
    LIMIT 1;

    -- Backfill phone_number_id so the next message finds it via the primary path.
    IF v_id IS NOT NULL THEN
      UPDATE conversations
      SET phone_number_id = p_phone_number_id,
          customer_id     = COALESCE(customer_id, v_customer_id)
      WHERE id = v_id;
    END IF;
  END IF;

  -- 3. Nothing found — create a new conversation.
  IF v_id IS NULL THEN
    IF v_phone IS NULL THEN
      SELECT cpn.phone_number, cpn.whatsapp_name, cpn.customer_id
      INTO v_phone, v_name, v_customer_id
      FROM customer_phone_numbers cpn
      WHERE cpn.id = p_phone_number_id;
    END IF;

    INSERT INTO conversations (phone_number_id, customer_id, phone_number, display_name, status, unread_count)
    VALUES (p_phone_number_id, v_customer_id, v_phone, v_name, 'open', 0)
    RETURNING conversations.id INTO v_id;
  END IF;

  RETURN QUERY SELECT v_id;
END;
$$;

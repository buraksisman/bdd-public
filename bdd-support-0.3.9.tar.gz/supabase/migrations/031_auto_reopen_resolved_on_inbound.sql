-- Migration 031: Auto-reopen resolved conversations on new inbound message
-- ─────────────────────────────────────────────────────────────────────────────
-- Statuses are display labels, not routing state (per migration 025). When a
-- customer messages again after the agent marked the conversation as
-- 'resolved', the row stays attached to the same conversation, but its label
-- should flip back to 'open' so the conversation re-surfaces in the list
-- without an unintended "Çözüldü" tag.
--
-- This extends the existing inbound trigger function. last_customer_msg_at /
-- window_expires_at logic is unchanged; we just also clear a 'resolved' label.

CREATE OR REPLACE FUNCTION update_window_from_inbound_message()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.direction = 'inbound' THEN
    UPDATE conversations
    SET
      last_customer_msg_at = NEW.created_at,
      window_expires_at    = NEW.created_at + INTERVAL '24 hours',
      status               = CASE WHEN status = 'resolved' THEN 'open' ELSE status END
    WHERE id = NEW.conversation_id;
  END IF;
  RETURN NEW;
END;
$$;

-- Migration 027: Single-session enforcement
-- ─────────────────────────────────────────────────────────────────────────────
-- Adds a per-user nonce that is rotated on every successful sign-in. Any other
-- browser tab subscribed to this profile row receives the UPDATE via Realtime
-- and force-logs-out immediately, so only one active session per user remains.

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS active_session_id TEXT;

-- Realtime: profiles must be in the publication and emit the new column on
-- UPDATE. REPLICA IDENTITY FULL ensures both old/new rows are streamed so the
-- client can compare against its own nonce.
ALTER TABLE profiles REPLICA IDENTITY FULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'profiles'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE profiles;
  END IF;
END
$$;

-- ───────────────────────────────────────────────────────────────────────
-- Phone-first architecture
-- ───────────────────────────────────────────────────────────────────────
-- Each WhatsApp phone is its own first-class record. A phone may or may
-- not be linked to a customer. Conversations are keyed by phone, not
-- customer. The customer entity becomes an admin-curated CRM record.

-- ─── customer_phone_numbers ─────────────────────────────────────────
ALTER TABLE customer_phone_numbers
  ALTER COLUMN customer_id DROP NOT NULL,
  ADD COLUMN IF NOT EXISTS whatsapp_name TEXT,
  ADD COLUMN IF NOT EXISTS tags TEXT[] NOT NULL DEFAULT '{}'::TEXT[];

-- Deleting a customer should leave the phone records intact (just unlink).
ALTER TABLE customer_phone_numbers
  DROP CONSTRAINT IF EXISTS customer_phone_numbers_customer_id_fkey;
ALTER TABLE customer_phone_numbers
  ADD CONSTRAINT customer_phone_numbers_customer_id_fkey
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;

-- Authenticated users can update tags / whatsapp_name on phones; service_role
-- (N8N) and admins keep full access via existing policies.
DROP POLICY IF EXISTS "Authenticated can update phone metadata" ON customer_phone_numbers;
CREATE POLICY "Authenticated can update phone metadata"
  ON customer_phone_numbers FOR UPDATE
  TO authenticated
  USING (true) WITH CHECK (true);

-- ─── conversations ───────────────────────────────────────────────────
-- Add the canonical phone reference and relax customer_id.
ALTER TABLE conversations
  ADD COLUMN IF NOT EXISTS phone_number_id UUID,
  ALTER COLUMN customer_id DROP NOT NULL;

ALTER TABLE conversations
  DROP CONSTRAINT IF EXISTS conversations_phone_number_id_fkey;
ALTER TABLE conversations
  ADD CONSTRAINT conversations_phone_number_id_fkey
    FOREIGN KEY (phone_number_id) REFERENCES customer_phone_numbers(id)
    ON DELETE CASCADE;

ALTER TABLE conversations
  DROP CONSTRAINT IF EXISTS conversations_customer_id_fkey;
ALTER TABLE conversations
  ADD CONSTRAINT conversations_customer_id_fkey
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_conversations_phone_number_id ON conversations(phone_number_id);

-- ─── customers ───────────────────────────────────────────────────────
-- phone_number is no longer the primary identity — relax it.
ALTER TABLE customers
  ALTER COLUMN phone_number DROP NOT NULL;

-- ─── RPCs ────────────────────────────────────────────────────────────
DROP FUNCTION IF EXISTS get_or_create_customer_by_phone(TEXT, TEXT);
DROP FUNCTION IF EXISTS get_or_create_conversation(UUID);
DROP FUNCTION IF EXISTS get_or_create_conversation(UUID, TEXT, TEXT);

-- Inbound entry. Records the phone (creating it if new), captures the
-- WhatsApp profile name on first sight, and returns identifiers for the
-- workflow to chain into get_or_create_conversation.
CREATE OR REPLACE FUNCTION register_inbound_phone(
  p_phone_number  TEXT,
  p_whatsapp_name TEXT DEFAULT NULL
)
RETURNS TABLE(phone_id UUID, customer_id UUID)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_phone_id    UUID;
  v_customer_id UUID;
  v_existing_name TEXT;
BEGIN
  SELECT cpn.id, cpn.customer_id, cpn.whatsapp_name
  INTO v_phone_id, v_customer_id, v_existing_name
  FROM customer_phone_numbers cpn
  WHERE cpn.phone_number = p_phone_number;

  IF v_phone_id IS NULL THEN
    INSERT INTO customer_phone_numbers (phone_number, whatsapp_name)
    VALUES (p_phone_number, NULLIF(p_whatsapp_name, ''))
    RETURNING customer_phone_numbers.id, customer_phone_numbers.customer_id
    INTO v_phone_id, v_customer_id;
  ELSIF p_whatsapp_name IS NOT NULL AND p_whatsapp_name <> ''
        AND (v_existing_name IS NULL OR v_existing_name = '') THEN
    UPDATE customer_phone_numbers
    SET whatsapp_name = p_whatsapp_name
    WHERE id = v_phone_id;
  END IF;

  RETURN QUERY SELECT v_phone_id, v_customer_id;
END;
$$;

-- Conversations are keyed by phone. Customer link is cached on the row.
CREATE OR REPLACE FUNCTION get_or_create_conversation(
  p_phone_number_id UUID
)
RETURNS TABLE(id UUID)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id          UUID;
  v_phone       TEXT;
  v_name        TEXT;
  v_customer_id UUID;
BEGIN
  SELECT c.id INTO v_id
  FROM conversations c
  WHERE c.phone_number_id = p_phone_number_id AND c.status = 'open'
  ORDER BY c.created_at DESC
  LIMIT 1;

  IF v_id IS NULL THEN
    SELECT cpn.phone_number, cpn.whatsapp_name, cpn.customer_id
    INTO v_phone, v_name, v_customer_id
    FROM customer_phone_numbers cpn
    WHERE cpn.id = p_phone_number_id;

    INSERT INTO conversations (phone_number_id, customer_id, phone_number, display_name, status, unread_count)
    VALUES (p_phone_number_id, v_customer_id, v_phone, v_name, 'open', 0)
    RETURNING conversations.id INTO v_id;
  END IF;

  RETURN QUERY SELECT v_id;
END;
$$;

-- Linking a phone to a customer also updates every conversation from that
-- phone so the cached customer_id stays in sync (used by the customer filter).
CREATE OR REPLACE FUNCTION link_phone_to_customer(
  p_phone_number      TEXT,
  p_target_customer_id UUID
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_phone_id UUID;
BEGIN
  UPDATE customer_phone_numbers
  SET customer_id = p_target_customer_id
  WHERE phone_number = p_phone_number
  RETURNING id INTO v_phone_id;

  IF v_phone_id IS NULL THEN
    RAISE EXCEPTION 'Phone number % not found', p_phone_number;
  END IF;

  UPDATE conversations
  SET customer_id = p_target_customer_id
  WHERE phone_number_id = v_phone_id;
END;
$$;

CREATE OR REPLACE FUNCTION unlink_phone_from_customer(
  p_phone_number TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_phone_id UUID;
BEGIN
  UPDATE customer_phone_numbers
  SET customer_id = NULL
  WHERE phone_number = p_phone_number
  RETURNING id INTO v_phone_id;

  UPDATE conversations
  SET customer_id = NULL
  WHERE phone_number_id = v_phone_id;
END;
$$;

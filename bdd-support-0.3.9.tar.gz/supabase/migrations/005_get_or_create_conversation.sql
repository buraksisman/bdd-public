-- Returns the existing open conversation for a customer, or creates a new one.
-- SECURITY DEFINER so N8N's service_role key can call it via RPC.
CREATE OR REPLACE FUNCTION get_or_create_conversation(p_customer_id UUID)
RETURNS TABLE(id UUID)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id UUID;
BEGIN
  SELECT c.id INTO v_id
  FROM conversations c
  WHERE c.customer_id = p_customer_id
    AND c.status = 'open'
  ORDER BY c.created_at DESC
  LIMIT 1;

  IF v_id IS NULL THEN
    INSERT INTO conversations (customer_id, status, unread_count)
    VALUES (p_customer_id, 'open', 0)
    RETURNING conversations.id INTO v_id;
  END IF;

  RETURN QUERY SELECT v_id;
END;
$$;

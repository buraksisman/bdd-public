-- Migration 023: Only update conversations.unread_count when it is actually > 0
-- ─────────────────────────────────────────────────────────────────────────────
-- Migration 022 introduced the unread_count reset inside mark_conversation_read.
-- The UPDATE fired unconditionally, even when unread_count was already 0, which
-- produced a spurious postgres_changes event on the conversations table every
-- time an agent opened or scrolled a conversation. That event caused
-- useRealtimeConversations to re-fetch and re-sort the list, making the active
-- conversation jump to the bottom.
--
-- Fix: guard the UPDATE with WHERE unread_count > 0.  When the count is already
-- 0 the statement is a no-op and Postgres does not emit a WAL record, so no
-- realtime event fires.

CREATE OR REPLACE FUNCTION mark_conversation_read(
  p_user_id         UUID,
  p_conversation_id UUID
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO conversation_reads (user_id, conversation_id, last_read_at)
  VALUES (p_user_id, p_conversation_id, NOW())
  ON CONFLICT (user_id, conversation_id) DO UPDATE
    SET last_read_at = NOW();

  -- Guard prevents a WAL write (and the resulting realtime event) when the
  -- count is already zero — i.e. the common case of re-opening an already-read
  -- conversation.
  UPDATE conversations
  SET unread_count = 0
  WHERE id = p_conversation_id AND unread_count > 0;
END;
$$;

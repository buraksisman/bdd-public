-- Migration 008: Persist last assigned agent on customer record
-- When a conversation is assigned, customers.last_assigned_to is updated.
-- New conversations inherit this assignment so routing survives conversation deletion.

-- 1. Add last_assigned_to to customers
ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS last_assigned_to UUID REFERENCES profiles(id) ON DELETE SET NULL;

-- 2. Trigger: sync customers.last_assigned_to when conversation assigned_to changes
CREATE OR REPLACE FUNCTION sync_customer_last_assigned()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  -- Only persist when assigning to an agent (not when releasing to pool)
  IF NEW.assigned_to IS NOT NULL AND NEW.assigned_to IS DISTINCT FROM OLD.assigned_to THEN
    UPDATE customers SET last_assigned_to = NEW.assigned_to WHERE id = NEW.customer_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_customer_last_assigned ON conversations;
CREATE TRIGGER trg_sync_customer_last_assigned
  AFTER UPDATE OF assigned_to ON conversations
  FOR EACH ROW EXECUTE FUNCTION sync_customer_last_assigned();

-- 3. get_or_create_conversation: new conversations inherit customer's last agent
CREATE OR REPLACE FUNCTION get_or_create_conversation(p_customer_id UUID)
RETURNS TABLE(id UUID)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id           UUID;
  v_last_assigned UUID;
BEGIN
  SELECT c.id INTO v_id
  FROM conversations c
  WHERE c.customer_id = p_customer_id
  ORDER BY c.created_at DESC
  LIMIT 1;

  IF v_id IS NULL THEN
    SELECT cust.last_assigned_to INTO v_last_assigned
    FROM customers cust
    WHERE cust.id = p_customer_id;

    INSERT INTO conversations (customer_id, status, assigned_to, unread_count)
    VALUES (p_customer_id, 'open', v_last_assigned, 0)
    RETURNING conversations.id INTO v_id;
  END IF;

  RETURN QUERY SELECT v_id;
END;
$$;

-- Migration 036: Teams-style private and group employee messaging.
CREATE TABLE internal_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), kind TEXT NOT NULL DEFAULT 'direct' CHECK (kind IN ('direct','group')),
  name TEXT, created_by UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  user_one UUID REFERENCES profiles(id) ON DELETE CASCADE, user_two UUID REFERENCES profiles(id) ON DELETE CASCADE,
  last_message_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT internal_conversations_shape CHECK (
    (kind='direct' AND user_one IS NOT NULL AND user_two IS NOT NULL AND user_one < user_two AND name IS NULL)
    OR (kind='group' AND user_one IS NULL AND user_two IS NULL AND NULLIF(BTRIM(name),'') IS NOT NULL))
);
CREATE UNIQUE INDEX internal_conversations_unique_direct ON internal_conversations(user_one,user_two) WHERE kind='direct';

CREATE TABLE internal_conversation_members (
  conversation_id UUID NOT NULL REFERENCES internal_conversations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  member_role TEXT NOT NULL DEFAULT 'member' CHECK (member_role IN ('owner','member')),
  joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), PRIMARY KEY (conversation_id,user_id)
);
CREATE TABLE internal_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), conversation_id UUID NOT NULL REFERENCES internal_conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, content TEXT,
  forwarded_message_id UUID REFERENCES messages(id) ON DELETE SET NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT internal_messages_has_content CHECK (NULLIF(BTRIM(content),'') IS NOT NULL OR forwarded_message_id IS NOT NULL)
);
CREATE TABLE internal_conversation_reads (
  conversation_id UUID NOT NULL REFERENCES internal_conversations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  last_read_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), PRIMARY KEY (conversation_id,user_id)
);
CREATE INDEX idx_internal_members_user ON internal_conversation_members(user_id,joined_at);
CREATE INDEX idx_internal_messages_conversation ON internal_messages(conversation_id,created_at);
CREATE INDEX idx_internal_messages_forwarded ON internal_messages(forwarded_message_id) WHERE forwarded_message_id IS NOT NULL;

ALTER TABLE internal_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE internal_conversation_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE internal_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE internal_conversation_reads ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION is_internal_conversation_member(p_conversation_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public,auth AS $$
  SELECT EXISTS (SELECT 1 FROM internal_conversation_members WHERE conversation_id=p_conversation_id AND user_id=auth.uid());
$$;
CREATE POLICY "internal conversations: members read" ON internal_conversations FOR SELECT TO authenticated USING (is_internal_conversation_member(id));
CREATE POLICY "internal members: members read" ON internal_conversation_members FOR SELECT TO authenticated USING (is_internal_conversation_member(conversation_id));
CREATE POLICY "internal messages: members read" ON internal_messages FOR SELECT TO authenticated USING (is_internal_conversation_member(conversation_id));
CREATE POLICY "internal messages: members send" ON internal_messages FOR INSERT TO authenticated WITH CHECK (sender_id=auth.uid() AND is_internal_conversation_member(conversation_id));
CREATE POLICY "internal reads: own read state" ON internal_conversation_reads FOR ALL TO authenticated
  USING (user_id=auth.uid() AND is_internal_conversation_member(conversation_id))
  WITH CHECK (user_id=auth.uid() AND is_internal_conversation_member(conversation_id));
CREATE POLICY "messages: internal forward recipients read" ON messages FOR SELECT TO authenticated USING (EXISTS (
  SELECT 1 FROM internal_messages im WHERE im.forwarded_message_id=messages.id AND is_internal_conversation_member(im.conversation_id)));
CREATE POLICY "attachments: internal forward recipients read" ON attachments FOR SELECT TO authenticated USING (EXISTS (
  SELECT 1 FROM internal_messages im WHERE im.forwarded_message_id=attachments.message_id AND is_internal_conversation_member(im.conversation_id)));

CREATE OR REPLACE FUNCTION get_or_create_internal_conversation(p_other_user UUID)
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,auth AS $$
DECLARE v_me UUID:=auth.uid(); v_one UUID; v_two UUID; v_id UUID;
BEGIN
  IF v_me IS NULL OR p_other_user IS NULL OR v_me=p_other_user THEN RAISE EXCEPTION 'invalid participant'; END IF;
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id=p_other_user AND is_active) THEN RAISE EXCEPTION 'participant not found'; END IF;
  IF v_me<p_other_user THEN v_one:=v_me; v_two:=p_other_user; ELSE v_one:=p_other_user; v_two:=v_me; END IF;
  INSERT INTO internal_conversations(kind,created_by,user_one,user_two) VALUES('direct',v_me,v_one,v_two)
  ON CONFLICT(user_one,user_two) WHERE kind='direct' DO UPDATE SET updated_at=internal_conversations.updated_at RETURNING id INTO v_id;
  INSERT INTO internal_conversation_members(conversation_id,user_id) VALUES(v_id,v_me),(v_id,p_other_user) ON CONFLICT DO NOTHING;
  RETURN v_id;
END; $$;

CREATE OR REPLACE FUNCTION create_internal_group(p_name TEXT,p_member_ids UUID[])
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,auth AS $$
DECLARE v_me UUID:=auth.uid(); v_id UUID; v_member UUID;
BEGIN
  IF v_me IS NULL OR LENGTH(BTRIM(COALESCE(p_name,'')))<2 THEN RAISE EXCEPTION 'invalid group name'; END IF;
  INSERT INTO internal_conversations(kind,name,created_by) VALUES('group',BTRIM(p_name),v_me) RETURNING id INTO v_id;
  INSERT INTO internal_conversation_members(conversation_id,user_id,member_role) VALUES(v_id,v_me,'owner');
  FOREACH v_member IN ARRAY COALESCE(p_member_ids,ARRAY[]::UUID[]) LOOP
    IF v_member<>v_me AND EXISTS(SELECT 1 FROM profiles WHERE id=v_member AND is_active) THEN
      INSERT INTO internal_conversation_members(conversation_id,user_id) VALUES(v_id,v_member) ON CONFLICT DO NOTHING;
    END IF;
  END LOOP;
  RETURN v_id;
END; $$;

CREATE OR REPLACE FUNCTION add_internal_group_member(p_conversation_id UUID,p_user_id UUID)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,auth AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM internal_conversations c JOIN internal_conversation_members m ON m.conversation_id=c.id
    WHERE c.id=p_conversation_id AND c.kind='group' AND m.user_id=auth.uid() AND m.member_role='owner') THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF NOT EXISTS(SELECT 1 FROM profiles WHERE id=p_user_id AND is_active) THEN RAISE EXCEPTION 'participant not found'; END IF;
  INSERT INTO internal_conversation_members(conversation_id,user_id) VALUES(p_conversation_id,p_user_id) ON CONFLICT DO NOTHING;
END; $$;
CREATE OR REPLACE FUNCTION rename_internal_group(p_conversation_id UUID,p_name TEXT)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,auth AS $$
BEGIN
  IF LENGTH(BTRIM(COALESCE(p_name,'')))<2 THEN RAISE EXCEPTION 'invalid group name'; END IF;
  IF NOT EXISTS (SELECT 1 FROM internal_conversations c JOIN internal_conversation_members m ON m.conversation_id=c.id
    WHERE c.id=p_conversation_id AND c.kind='group' AND m.user_id=auth.uid() AND m.member_role='owner') THEN RAISE EXCEPTION 'forbidden'; END IF;
  UPDATE internal_conversations SET name=BTRIM(p_name),updated_at=NOW() WHERE id=p_conversation_id;
END; $$;
CREATE OR REPLACE FUNCTION remove_internal_group_member(p_conversation_id UUID,p_user_id UUID)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,auth AS $$
DECLARE v_owner UUID;
BEGIN
  SELECT created_by INTO v_owner FROM internal_conversations WHERE id=p_conversation_id AND kind='group';
  IF v_owner IS NULL OR NOT EXISTS (SELECT 1 FROM internal_conversation_members
    WHERE conversation_id=p_conversation_id AND user_id=auth.uid() AND member_role='owner') THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF p_user_id=v_owner THEN RAISE EXCEPTION 'owner cannot be removed'; END IF;
  DELETE FROM internal_conversation_members WHERE conversation_id=p_conversation_id AND user_id=p_user_id;
END; $$;
CREATE OR REPLACE FUNCTION mark_internal_conversation_read(p_conversation_id UUID)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,auth AS $$
BEGIN
  IF NOT is_internal_conversation_member(p_conversation_id) THEN RAISE EXCEPTION 'forbidden'; END IF;
  INSERT INTO internal_conversation_reads(conversation_id,user_id,last_read_at) VALUES(p_conversation_id,auth.uid(),NOW())
  ON CONFLICT(conversation_id,user_id) DO UPDATE SET last_read_at=NOW();
END; $$;
CREATE OR REPLACE FUNCTION touch_internal_conversation() RETURNS TRIGGER LANGUAGE plpgsql SET search_path=public AS $$
BEGIN UPDATE internal_conversations SET last_message_at=NEW.created_at,updated_at=NOW() WHERE id=NEW.conversation_id; RETURN NEW; END; $$;
CREATE TRIGGER trg_internal_message_touch AFTER INSERT ON internal_messages FOR EACH ROW EXECUTE FUNCTION touch_internal_conversation();

GRANT SELECT ON internal_conversations,internal_conversation_members,internal_messages,internal_conversation_reads TO authenticated;
GRANT INSERT ON internal_messages,internal_conversation_reads TO authenticated;
GRANT UPDATE ON internal_conversation_reads TO authenticated;
GRANT EXECUTE ON FUNCTION is_internal_conversation_member(UUID),get_or_create_internal_conversation(UUID),create_internal_group(TEXT,UUID[]),add_internal_group_member(UUID,UUID),rename_internal_group(UUID,TEXT),remove_internal_group_member(UUID,UUID),mark_internal_conversation_read(UUID) TO authenticated;
ALTER TABLE internal_conversations REPLICA IDENTITY FULL;
ALTER TABLE internal_conversation_members REPLICA IDENTITY FULL;
ALTER TABLE internal_messages REPLICA IDENTITY FULL;
ALTER TABLE internal_conversation_reads REPLICA IDENTITY FULL;
DO $$ BEGIN
  IF NOT EXISTS(SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND tablename='internal_conversations') THEN ALTER PUBLICATION supabase_realtime ADD TABLE internal_conversations; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND tablename='internal_conversation_members') THEN ALTER PUBLICATION supabase_realtime ADD TABLE internal_conversation_members; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND tablename='internal_messages') THEN ALTER PUBLICATION supabase_realtime ADD TABLE internal_messages; END IF;
  IF NOT EXISTS(SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND tablename='internal_conversation_reads') THEN ALTER PUBLICATION supabase_realtime ADD TABLE internal_conversation_reads; END IF;
END $$;

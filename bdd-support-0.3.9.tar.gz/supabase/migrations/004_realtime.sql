-- Migration 004: Supabase Realtime Etkinleştirme
-- Danışmanların gerçek zamanlı güncellemeler alacağı tablolar

-- Realtime publication'a tabloları ekle
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE conversations;
ALTER PUBLICATION supabase_realtime ADD TABLE representative_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE conversation_reads;

-- Not: Supabase'de Realtime ayrıca Dashboard > Database > Replication
-- bölümünden de etkinleştirilebilir. Bu migration lokal kurulumda çalışır.
-- Production için Dashboard üzerinden de doğrulayın.

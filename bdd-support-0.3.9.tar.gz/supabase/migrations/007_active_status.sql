-- Migration 007: Add 'active' status to the enum constraint
-- Status values: open (new/pool), active (tag), waiting (tag), resolved (tag)
-- Pool logic remains assigned_to IS NULL — statuses are agent-applied tags.

-- 1. Drop old check constraint and add new one with 'active'
ALTER TABLE conversations DROP CONSTRAINT IF EXISTS conversations_status_check;
ALTER TABLE conversations ADD CONSTRAINT conversations_status_check
  CHECK (status IN ('open', 'active', 'waiting', 'resolved'));

-- 2. Update claim_conversation: assign only, do NOT change status
--    Status remains 'open' after claiming; agent sets tags manually.
CREATE OR REPLACE FUNCTION claim_conversation(
  p_conversation_id UUID,
  p_user_id         UUID
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE conversations
  SET assigned_to = p_user_id,
      updated_at  = NOW()
  WHERE id          = p_conversation_id
    AND assigned_to IS NULL;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Bu konuşma başka bir danışman tarafından alınmış.';
  END IF;
END;
$$;

-- 3. get_or_create_conversation: single-conversation-per-customer rule.
--    Statuses are tags only — no automatic status changes on new message.
--    New message goes to existing conversation regardless of status.
--    assigned_to preserved: if agent set, message reaches same agent; if null, stays in pool.
CREATE OR REPLACE FUNCTION get_or_create_conversation(p_customer_id UUID)
RETURNS TABLE(id UUID)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id UUID;
BEGIN
  SELECT c.id INTO v_id
  FROM conversations c
  WHERE c.customer_id = p_customer_id
  ORDER BY c.created_at DESC
  LIMIT 1;

  IF v_id IS NULL THEN
    INSERT INTO conversations (customer_id, status, unread_count)
    VALUES (p_customer_id, 'open', 0)
    RETURNING conversations.id INTO v_id;
  END IF;

  RETURN QUERY SELECT v_id;
END;
$$;

-- Migration 006: Realtime tabloları için REPLICA IDENTITY FULL
-- Supabase Realtime, UPDATE/DELETE olaylarında RLS filtrelemesi yapabilmek
-- için row'un eski halini bilmesi gerekir. DEFAULT sadece PK'yı içerir,
-- bu yüzden assigned_to gibi alanlar değiştiğinde olay iletilmeyebilir.
ALTER TABLE conversations           REPLICA IDENTITY FULL;
ALTER TABLE messages                REPLICA IDENTITY FULL;
ALTER TABLE representative_sessions REPLICA IDENTITY FULL;
ALTER TABLE conversation_reads      REPLICA IDENTITY FULL;

-- Migration 030: Seed BDD Müşavirlik intro template
-- ─────────────────────────────────────────────────────────────────────────────
-- NOTE: This row reflects a template that must be approved in Meta Business
-- Manager under the SAME name + language. Until Meta approves it, sending
-- this template will fail with "template not found" from WhatsApp Cloud API.

INSERT INTO whatsapp_templates (name, language, body_text, placeholder_count, category)
VALUES (
  'bdd_intro',
  'tr',
  'Merhaba. Size BDD Müşavirlik adına yazıyorum. Müsait misiniz?',
  0,
  'UTILITY'
)
ON CONFLICT (name, language) DO UPDATE
  SET body_text         = EXCLUDED.body_text,
      placeholder_count = EXCLUDED.placeholder_count,
      category          = EXCLUDED.category,
      is_active         = true;

-- Migration 013: Update conversations.window_expires_at via messages trigger
--
-- N8N only updates conversations.last_message_at, not last_customer_msg_at.
-- The existing trg_conversations_window fires on UPDATE OF last_customer_msg_at,
-- which never happens from N8N, so window_expires_at stays stale.
-- This trigger fires on inbound message INSERT and directly updates the window.

CREATE OR REPLACE FUNCTION update_window_from_inbound_message()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.direction = 'inbound' THEN
    UPDATE conversations
    SET
      last_customer_msg_at = NEW.created_at,
      window_expires_at    = NEW.created_at + INTERVAL '24 hours'
    WHERE id = NEW.conversation_id;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_messages_update_window
  AFTER INSERT ON messages
  FOR EACH ROW EXECUTE FUNCTION update_window_from_inbound_message();

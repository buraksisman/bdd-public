-- Migration 028: Customer-side message edit / delete sync
-- ─────────────────────────────────────────────────────────────────────────────
-- WhatsApp Cloud API emits a "message edited" webhook for inbound messages.
-- Customer-side delete is not natively pushed by WhatsApp, but we keep the
-- column in place so any custom N8N pipeline (or a future agent-side flag)
-- can mark a message as deleted-by-customer with a single UPDATE.
--
-- N8N contract (service_role, RLS bypass):
--   Edit:   UPDATE messages
--           SET content = $new_content, edited_at = NOW()
--           WHERE whatsapp_message_id = $wamid;
--
--   Delete: UPDATE messages
--           SET deleted_at = NOW()
--           WHERE whatsapp_message_id = $wamid;
--
-- The UI reads `deleted_at` first (placeholder, hides content + attachments),
-- then falls back to `edited_at` (renders content + "(düzenlendi)" badge).

ALTER TABLE messages
  ADD COLUMN IF NOT EXISTS edited_at  TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Lookups happen by whatsapp_message_id (already indexed via idx_messages_wa_id).
-- No further index needed; edited_at / deleted_at are read alongside the row.

-- Migration 012: Simplify messages SELECT RLS for Supabase Realtime compatibility
--
-- The previous policy used a complex EXISTS subquery with auth.uid() which causes
-- Supabase Realtime to silently drop postgres_changes events (known limitation).
-- Since this is a single-tenant support tool, all authenticated users are company
-- agents who should be able to read messages. Conversation-level access control
-- is enforced in the UI layer, not needed on messages SELECT.

DROP POLICY IF EXISTS "messages: erişilebilir konuşmaların mesajları okunabilir" ON messages;

CREATE POLICY "messages: authenticated users can read all messages"
  ON messages FOR SELECT
  TO authenticated
  USING (true);

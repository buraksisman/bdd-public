-- ───────────────────────────────────────────────────────────────────────
-- Phone-first follow-ups
-- ───────────────────────────────────────────────────────────────────────
-- 1) The customers table never had an INSERT policy for authenticated —
--    only service_role (N8N) could insert. The phone-first flow asks
--    admins to create customers from the sidebar, so allow that.
-- 2) Columns added in migration 017 (whatsapp_name, tags) didn't inherit
--    the table-level UPDATE grant for the authenticated role, so the JS
--    client's update silently no-op'd. Re-grant explicitly.

-- ─── customers: admins can insert ─────────────────────────────────────
DROP POLICY IF EXISTS "customers: admin ekleyebilir" ON customers;
CREATE POLICY "customers: admin ekleyebilir"
  ON customers FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- Symmetric DELETE so createCustomerAndAttachPhone can roll back its own
-- insert if linking the phone afterward fails.
DROP POLICY IF EXISTS "customers: admin silebilir" ON customers;
CREATE POLICY "customers: admin silebilir"
  ON customers FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- ─── customer_phone_numbers: re-grant on the new columns ──────────────
GRANT SELECT, UPDATE (whatsapp_name, tags) ON customer_phone_numbers TO authenticated;
GRANT SELECT, UPDATE (whatsapp_name, tags) ON customer_phone_numbers TO anon;

-- Migration 026: Prefer assigned conversations in get_or_create_conversation
-- ─────────────────────────────────────────────────────────────────────────────
-- Migration 025 removed the status='open' filter so that status labels do not
-- affect message routing. However it still used ORDER BY created_at DESC, which
-- could pick a newer POOL conversation (assigned_to IS NULL) created by the old
-- bug over an older ASSIGNED conversation (assigned_to IS NOT NULL) that the
-- agent is actively viewing.
--
-- Fix: sort assigned conversations before pool ones, then by most recent.
-- Same fix applied to the legacy-phone fallback path.

CREATE OR REPLACE FUNCTION get_or_create_conversation(
  p_phone_number_id UUID
)
RETURNS TABLE(id UUID)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id          UUID;
  v_phone       TEXT;
  v_name        TEXT;
  v_customer_id UUID;
BEGIN
  -- 1. Primary lookup: prefer assigned conversations over pool ones.
  SELECT c.id INTO v_id
  FROM conversations c
  WHERE c.phone_number_id = p_phone_number_id
  ORDER BY
    CASE WHEN c.assigned_to IS NOT NULL THEN 0 ELSE 1 END ASC,
    c.created_at DESC
  LIMIT 1;

  -- 2. Fallback: legacy conversations (phone_number_id IS NULL) created before
  --    migration 017. Same assignment preference applied.
  IF v_id IS NULL THEN
    SELECT cpn.phone_number, cpn.whatsapp_name, cpn.customer_id
    INTO v_phone, v_name, v_customer_id
    FROM customer_phone_numbers cpn
    WHERE cpn.id = p_phone_number_id;

    SELECT c.id INTO v_id
    FROM conversations c
    WHERE c.phone_number = v_phone
      AND c.phone_number_id IS NULL
    ORDER BY
      CASE WHEN c.assigned_to IS NOT NULL THEN 0 ELSE 1 END ASC,
      c.created_at DESC
    LIMIT 1;

    IF v_id IS NOT NULL THEN
      UPDATE conversations
      SET phone_number_id = p_phone_number_id,
          customer_id     = COALESCE(customer_id, v_customer_id)
      WHERE id = v_id;
    END IF;
  END IF;

  -- 3. No conversation exists — create one in the pool.
  IF v_id IS NULL THEN
    IF v_phone IS NULL THEN
      SELECT cpn.phone_number, cpn.whatsapp_name, cpn.customer_id
      INTO v_phone, v_name, v_customer_id
      FROM customer_phone_numbers cpn
      WHERE cpn.id = p_phone_number_id;
    END IF;

    INSERT INTO conversations (phone_number_id, customer_id, phone_number, display_name, status, unread_count)
    VALUES (p_phone_number_id, v_customer_id, v_phone, v_name, 'open', 0)
    RETURNING conversations.id INTO v_id;
  END IF;

  RETURN QUERY SELECT v_id;
END;
$$;

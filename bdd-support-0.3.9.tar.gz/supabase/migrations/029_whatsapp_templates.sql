-- Migration 029: WhatsApp approved templates + outbound template support
-- ─────────────────────────────────────────────────────────────────────────────
-- Outside the 24h window WhatsApp Cloud API rejects free-form text with
-- error 131047 ("re-engagement message"). The only legal first contact is
-- an approved template. We store approved template definitions in our DB
-- (kept in sync with Meta Business Manager by hand for now) so agents can
-- pick + parameterize them from the chat UI.
--
-- Outbound flow:
--   1. Agent picks template, fills {{1}}…{{n}} placeholders.
--   2. Server action inserts a `messages` row with:
--        message_type = 'template'
--        content      = preview text (placeholders substituted, for the UI)
--        template_data = { name, language, parameters }
--   3. N8N outbound poller sees message_type='template', builds the WA
--      template API body from template_data, and POSTs to Cloud API.

CREATE TABLE IF NOT EXISTS whatsapp_templates (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name              TEXT NOT NULL,
  language          TEXT NOT NULL DEFAULT 'en_US',
  body_text         TEXT NOT NULL,             -- with {{1}}, {{2}} placeholders
  placeholder_count INTEGER NOT NULL DEFAULT 0,
  category          TEXT NOT NULL DEFAULT 'UTILITY'
                      CHECK (category IN ('UTILITY', 'MARKETING', 'AUTHENTICATION')),
  is_active         BOOLEAN NOT NULL DEFAULT true,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (name, language)
);

CREATE TRIGGER trg_whatsapp_templates_updated_at
  BEFORE UPDATE ON whatsapp_templates
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

ALTER TABLE whatsapp_templates ENABLE ROW LEVEL SECURITY;

-- Agents need to list active templates from the picker.
CREATE POLICY "whatsapp_templates: authenticated can read active"
  ON whatsapp_templates FOR SELECT
  TO authenticated
  USING (is_active);

-- Admin-managed for now (no UI yet — INSERT/UPDATE via service_role or SQL).
-- We grant admins via the same is_admin() pattern used elsewhere.
CREATE POLICY "whatsapp_templates: admin write"
  ON whatsapp_templates FOR ALL
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  );

-- Outbound payload on messages.
ALTER TABLE messages
  ADD COLUMN IF NOT EXISTS template_data JSONB;

-- Seed Meta's default pre-approved template so the round-trip works
-- on every WhatsApp Business account out of the box.
INSERT INTO whatsapp_templates (name, language, body_text, placeholder_count, category)
VALUES ('hello_world', 'en_US', 'Hello World', 0, 'UTILITY')
ON CONFLICT (name, language) DO NOTHING;

-- Migration 022: Automatic unread_count management
-- ─────────────────────────────────────────────────────────────────────────────
-- conversations.unread_count has always been 0 because nothing incremented it.
-- This migration:
--   1. Adds an AFTER INSERT trigger on messages that increments unread_count
--      for every inbound message.
--   2. Updates mark_conversation_read to also reset unread_count = 0 so the
--      badge clears the moment the agent opens the conversation.

-- Trigger function: fires after each inbound message row is inserted.
CREATE OR REPLACE FUNCTION increment_conversation_unread()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.direction = 'inbound' THEN
    UPDATE conversations
    SET unread_count = unread_count + 1
    WHERE id = NEW.conversation_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_message_insert_update_unread ON messages;
CREATE TRIGGER on_message_insert_update_unread
  AFTER INSERT ON messages
  FOR EACH ROW EXECUTE FUNCTION increment_conversation_unread();

-- Updated mark_conversation_read: also resets the shared unread counter.
-- The counter is shared (not per-agent) which is correct for the current model
-- where each conversation is assigned to exactly one agent.
CREATE OR REPLACE FUNCTION mark_conversation_read(
  p_user_id         UUID,
  p_conversation_id UUID
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO conversation_reads (user_id, conversation_id, last_read_at)
  VALUES (p_user_id, p_conversation_id, NOW())
  ON CONFLICT (user_id, conversation_id) DO UPDATE
    SET last_read_at = NOW();

  UPDATE conversations
  SET unread_count = 0
  WHERE id = p_conversation_id;
END;
$$;

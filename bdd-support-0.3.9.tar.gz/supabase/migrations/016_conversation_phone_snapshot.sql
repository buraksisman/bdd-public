-- Each conversation snapshots the inbound phone number + display name at the
-- time it was created. This way, linking the phone to a different customer
-- later does not change what the conversation list shows for the conversation.
ALTER TABLE conversations
  ADD COLUMN IF NOT EXISTS phone_number TEXT,
  ADD COLUMN IF NOT EXISTS display_name TEXT;

-- Backfill from the current customer for existing rows.
UPDATE conversations c
SET phone_number = COALESCE(c.phone_number, cu.phone_number),
    display_name = COALESCE(c.display_name, cu.display_name)
FROM customers cu
WHERE cu.id = c.customer_id
  AND (c.phone_number IS NULL OR c.display_name IS NULL);

-- Replace get_or_create_conversation so it can record the snapshot when a new
-- conversation is created. Backward compatible: existing N8N calls without the
-- new params still work — the trigger derives the snapshot from the customer.
DROP FUNCTION IF EXISTS get_or_create_conversation(UUID);
CREATE OR REPLACE FUNCTION get_or_create_conversation(
  p_customer_id UUID,
  p_phone_number TEXT DEFAULT NULL,
  p_display_name TEXT DEFAULT NULL
)
RETURNS TABLE(id UUID)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id UUID;
  v_phone TEXT;
  v_name TEXT;
BEGIN
  SELECT c.id INTO v_id
  FROM conversations c
  WHERE c.customer_id = p_customer_id
    AND c.status = 'open'
  ORDER BY c.created_at DESC
  LIMIT 1;

  IF v_id IS NULL THEN
    -- Use passed-in values, or fall back to whatever the customer record
    -- currently has (which, on the inbound path, was just set/looked up by
    -- the caller from this exact phone).
    SELECT
      COALESCE(p_phone_number, cu.phone_number),
      COALESCE(p_display_name, cu.display_name)
    INTO v_phone, v_name
    FROM customers cu WHERE cu.id = p_customer_id;

    INSERT INTO conversations (customer_id, status, unread_count, phone_number, display_name)
    VALUES (p_customer_id, 'open', 0, v_phone, v_name)
    RETURNING conversations.id INTO v_id;
  END IF;

  RETURN QUERY SELECT v_id;
END;
$$;

-- link_phone_to_customer must NOT clear phone_number/display_name on
-- conversations being moved — that's the snapshot we want to preserve.
-- The existing function only updates customer_id, which is fine.

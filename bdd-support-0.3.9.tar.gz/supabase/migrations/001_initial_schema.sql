-- AB Mali Müşavirlik ve Danışma — Initial Schema
-- Migration 001: Core tables

-- ─────────────────────────────────────────
-- profiles: Danışman profilleri (auth.users uzantısı)
-- ─────────────────────────────────────────
CREATE TABLE profiles (
  id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name   TEXT NOT NULL,
  email       TEXT NOT NULL,
  avatar_url  TEXT,
  role        TEXT NOT NULL DEFAULT 'agent' CHECK (role IN ('agent', 'admin')),
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- customers: Müşteri kayıtları
-- ─────────────────────────────────────────
CREATE TABLE customers (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number  TEXT NOT NULL UNIQUE,  -- E.164 format: +905xxxxxxxxx
  display_name  TEXT,
  email         TEXT,
  notes         TEXT,
  external_ref  TEXT,                  -- harici DB arama anahtarı
  meta          JSONB NOT NULL DEFAULT '{}',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_customers_phone ON customers(phone_number);
CREATE INDEX idx_customers_external_ref ON customers(external_ref) WHERE external_ref IS NOT NULL;

-- ─────────────────────────────────────────
-- conversations: Konuşmalar
-- ─────────────────────────────────────────
CREATE TABLE conversations (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id           UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  assigned_to           UUID REFERENCES profiles(id) ON DELETE SET NULL,  -- NULL = shared pool
  status                TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'resolved', 'waiting')),
  last_message_at       TIMESTAMPTZ,
  last_customer_msg_at  TIMESTAMPTZ,
  window_expires_at     TIMESTAMPTZ,  -- last_customer_msg_at + 24h, trigger ile güncellenir
  unread_count          INTEGER NOT NULL DEFAULT 0,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_conversations_assigned_to   ON conversations(assigned_to);
CREATE INDEX idx_conversations_status        ON conversations(status);
CREATE INDEX idx_conversations_customer_id   ON conversations(customer_id);
CREATE INDEX idx_conversations_last_msg      ON conversations(last_message_at DESC NULLS LAST);
CREATE INDEX idx_conversations_pool          ON conversations(status) WHERE assigned_to IS NULL;

-- ─────────────────────────────────────────
-- messages: Mesajlar
-- ─────────────────────────────────────────
CREATE TABLE messages (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id      UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_type          TEXT NOT NULL CHECK (sender_type IN ('customer', 'agent', 'system')),
  sender_id            UUID REFERENCES profiles(id) ON DELETE SET NULL,
  content              TEXT,
  message_type         TEXT NOT NULL DEFAULT 'text'
                         CHECK (message_type IN ('text', 'image', 'document', 'audio', 'video', 'sticker', 'template', 'system')),
  whatsapp_message_id  TEXT UNIQUE,
  direction            TEXT NOT NULL CHECK (direction IN ('inbound', 'outbound')),
  status               TEXT NOT NULL DEFAULT 'pending'
                         CHECK (status IN ('pending', 'sent', 'delivered', 'read', 'failed')),
  error_message        TEXT,
  sent_at              TIMESTAMPTZ,
  delivered_at         TIMESTAMPTZ,
  read_at              TIMESTAMPTZ,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_messages_conversation_id ON messages(conversation_id, created_at ASC);
-- Partial index: N8N sadece pending outbound mesajları tarar
CREATE INDEX idx_messages_pending_outbound ON messages(created_at ASC)
  WHERE status = 'pending' AND direction = 'outbound';
CREATE INDEX idx_messages_wa_id            ON messages(whatsapp_message_id) WHERE whatsapp_message_id IS NOT NULL;

-- ─────────────────────────────────────────
-- attachments: Dosya ekleri
-- ─────────────────────────────────────────
CREATE TABLE attachments (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id          UUID NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  file_name           TEXT,
  file_type           TEXT,               -- MIME: image/jpeg, application/pdf...
  file_url            TEXT NOT NULL,      -- Supabase Storage path
  file_size_bytes     INTEGER,
  whatsapp_media_id   TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_attachments_message_id ON attachments(message_id);

-- ─────────────────────────────────────────
-- representative_sessions: Heartbeat / online durumu
-- ─────────────────────────────────────────
CREATE TABLE representative_sessions (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                  UUID NOT NULL UNIQUE REFERENCES profiles(id) ON DELETE CASCADE,
  last_seen_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  is_online                BOOLEAN NOT NULL DEFAULT false,
  current_conversation_id  UUID REFERENCES conversations(id) ON DELETE SET NULL,
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- conversation_reads: Okundu takibi (per-agent)
-- ─────────────────────────────────────────
CREATE TABLE conversation_reads (
  user_id          UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  conversation_id  UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  last_read_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, conversation_id)
);

CREATE INDEX idx_conversation_reads_user ON conversation_reads(user_id);

-- ─────────────────────────────────────────
-- updated_at otomatik güncelleme trigger'ı
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_customers_updated_at
  BEFORE UPDATE ON customers
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_conversations_updated_at
  BEFORE UPDATE ON conversations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_representative_sessions_updated_at
  BEFORE UPDATE ON representative_sessions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

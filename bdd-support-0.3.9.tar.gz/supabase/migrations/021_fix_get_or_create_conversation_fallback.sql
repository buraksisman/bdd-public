-- Migration 021: get_or_create_conversation fallback for legacy conversations
-- ─────────────────────────────────────────────────────────────────────────────
-- Conversations created before migration 017 (or via the old N8N workflow
-- before it was re-imported) have phone_number_id = NULL. The phone-first
-- get_or_create_conversation only searched by phone_number_id, so those
-- conversations were invisible to it — causing a duplicate open conversation
-- to be created in the pool for every inbound message from a known number.
--
-- Fix: add a fallback lookup by the phone_number TEXT snapshot column, and
-- backfill phone_number_id on any legacy conversation found that way.

CREATE OR REPLACE FUNCTION get_or_create_conversation(
  p_phone_number_id UUID
)
RETURNS TABLE(id UUID)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id          UUID;
  v_phone       TEXT;
  v_name        TEXT;
  v_customer_id UUID;
BEGIN
  -- 1. Primary lookup: phone_number_id (all new conversations)
  SELECT c.id INTO v_id
  FROM conversations c
  WHERE c.phone_number_id = p_phone_number_id AND c.status = 'open'
  ORDER BY c.created_at DESC
  LIMIT 1;

  -- 2. Fallback: legacy conversations that predate migration 017 and have
  --    phone_number_id = NULL but do have the phone_number text snapshot.
  IF v_id IS NULL THEN
    SELECT cpn.phone_number, cpn.whatsapp_name, cpn.customer_id
    INTO v_phone, v_name, v_customer_id
    FROM customer_phone_numbers cpn
    WHERE cpn.id = p_phone_number_id;

    SELECT c.id INTO v_id
    FROM conversations c
    WHERE c.phone_number = v_phone
      AND c.phone_number_id IS NULL
      AND c.status = 'open'
    ORDER BY c.created_at DESC
    LIMIT 1;

    -- Backfill phone_number_id so the next message finds it via the primary path.
    IF v_id IS NOT NULL THEN
      UPDATE conversations
      SET phone_number_id = p_phone_number_id,
          customer_id     = COALESCE(customer_id, v_customer_id)
      WHERE id = v_id;
    END IF;
  END IF;

  -- 3. Nothing found — create a new conversation.
  IF v_id IS NULL THEN
    -- v_phone might already be set from step 2; if not, fetch now.
    IF v_phone IS NULL THEN
      SELECT cpn.phone_number, cpn.whatsapp_name, cpn.customer_id
      INTO v_phone, v_name, v_customer_id
      FROM customer_phone_numbers cpn
      WHERE cpn.id = p_phone_number_id;
    END IF;

    INSERT INTO conversations (phone_number_id, customer_id, phone_number, display_name, status, unread_count)
    VALUES (p_phone_number_id, v_customer_id, v_phone, v_name, 'open', 0)
    RETURNING conversations.id INTO v_id;
  END IF;

  RETURN QUERY SELECT v_id;
END;
$$;

-- Migration 009: Customer Files Module
-- Her müşteri için ayrı klasörde doküman dosyası depolama

-- Storage bucket oluştur
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'customer-files',
  'customer-files',
  false,
  26214400,
  ARRAY['image/jpeg','image/png','image/gif','image/webp','application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation','text/plain','text/csv']
) ON CONFLICT (id) DO NOTHING;

-- Storage policies
CREATE POLICY "Authenticated users can upload customer-files"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'customer-files' AND auth.role() IN ('authenticated', 'service_role'));

CREATE POLICY "Everyone can view customer-files"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'customer-files');

CREATE POLICY "Service role can delete customer-files"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'customer-files' AND auth.role() = 'service_role');

-- customer_files: Müşteri doküman dosyaları
CREATE TABLE customer_files (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id     UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  file_name       TEXT NOT NULL,
  file_type       TEXT NOT NULL,
  file_path       TEXT NOT NULL,
  file_size_bytes INTEGER,
  uploaded_by     UUID REFERENCES profiles(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_customer_files_customer_id ON customer_files(customer_id);
CREATE INDEX idx_customer_files_created_at ON customer_files(created_at DESC);

-- RLS policies for customer_files
ALTER TABLE customer_files ENABLE ROW LEVEL SECURITY;

-- Everyone can read files
CREATE POLICY "Anyone can read customer_files"
  ON customer_files FOR SELECT
  USING (true);

-- Authenticated users can insert
CREATE POLICY "Authenticated can insert customer_files"
  ON customer_files FOR INSERT
  WITH CHECK (auth.role() IN ('authenticated', 'service_role'));

-- Only admins can delete
CREATE POLICY "Admins can delete customer_files"
  ON customer_files FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

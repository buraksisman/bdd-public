-- Migration 011: Multi-phone customer support
-- Bir müşteri birden fazla telefon numarasına sahip olabilir.

-- ─────────────────────────────────────────
-- customer_phone_numbers: Telefon → Müşteri eşleşmesi
-- ─────────────────────────────────────────
CREATE TABLE customer_phone_numbers (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id  UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  phone_number TEXT NOT NULL,
  is_primary   BOOLEAN NOT NULL DEFAULT false,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT customer_phone_numbers_phone_unique UNIQUE (phone_number)
);

CREATE INDEX idx_cpn_customer ON customer_phone_numbers(customer_id);
CREATE INDEX idx_cpn_phone    ON customer_phone_numbers(phone_number);

-- Mevcut customers.phone_number verilerini aktar
INSERT INTO customer_phone_numbers (customer_id, phone_number, is_primary)
SELECT id, phone_number, true FROM customers
ON CONFLICT (phone_number) DO NOTHING;

-- RLS
ALTER TABLE customer_phone_numbers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read phone numbers"
  ON customer_phone_numbers FOR SELECT TO authenticated USING (true);

CREATE POLICY "Service role full access"
  ON customer_phone_numbers FOR ALL TO service_role USING (true);

CREATE POLICY "Admins can manage phone numbers"
  ON customer_phone_numbers FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin'));

-- ─────────────────────────────────────────
-- customer_files: conversation_id ekle
-- ─────────────────────────────────────────
ALTER TABLE customer_files
  ADD COLUMN conversation_id UUID REFERENCES conversations(id) ON DELETE SET NULL;

CREATE INDEX idx_customer_files_conversation ON customer_files(conversation_id);

-- ─────────────────────────────────────────
-- RPC: get_or_create_customer_by_phone
-- N8N inbound bu RPC'yi çağırır.
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION get_or_create_customer_by_phone(
  p_phone_number TEXT,
  p_display_name TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_customer_id UUID;
BEGIN
  -- Önce customer_phone_numbers tablosuna bak
  SELECT customer_id INTO v_customer_id
  FROM customer_phone_numbers
  WHERE phone_number = p_phone_number;

  IF v_customer_id IS NOT NULL THEN
    -- İsim geldiyse ve mevcut isim boş/telefon numarasıysa güncelle
    IF p_display_name IS NOT NULL THEN
      UPDATE customers
      SET display_name = p_display_name, updated_at = NOW()
      WHERE id = v_customer_id
        AND (display_name IS NULL OR display_name = '' OR display_name = phone_number);
    END IF;
    RETURN v_customer_id;
  END IF;

  -- Yeni müşteri oluştur
  INSERT INTO customers (phone_number, display_name)
  VALUES (p_phone_number, COALESCE(NULLIF(p_display_name, ''), p_phone_number))
  ON CONFLICT (phone_number) DO UPDATE
    SET display_name = CASE
          WHEN p_display_name IS NOT NULL
            AND (customers.display_name IS NULL OR customers.display_name = customers.phone_number)
          THEN p_display_name
          ELSE customers.display_name
        END,
        updated_at = NOW()
  RETURNING id INTO v_customer_id;

  -- Telefon numarasını customer_phone_numbers'a ekle
  INSERT INTO customer_phone_numbers (customer_id, phone_number, is_primary)
  VALUES (v_customer_id, p_phone_number, true)
  ON CONFLICT (phone_number) DO NOTHING;

  RETURN v_customer_id;
END;
$$;

-- ─────────────────────────────────────────
-- RPC: link_phone_to_customer
-- Admin, bir telefon numarasını mevcut bir müşteriye bağlar.
-- Bağlı tüm konuşmalar ve dosyalar hedef müşteriye taşınır.
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION link_phone_to_customer(
  p_phone_number   TEXT,
  p_target_customer_id UUID
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_old_customer_id UUID;
BEGIN
  SELECT customer_id INTO v_old_customer_id
  FROM customer_phone_numbers
  WHERE phone_number = p_phone_number;

  -- Zaten doğru müşteriye bağlıysa çık
  IF v_old_customer_id = p_target_customer_id THEN
    RETURN;
  END IF;

  -- Telefon numarasını hedef müşteriye bağla
  UPDATE customer_phone_numbers
  SET customer_id = p_target_customer_id, is_primary = false
  WHERE phone_number = p_phone_number;

  IF v_old_customer_id IS NOT NULL THEN
    -- Tüm konuşmaları taşı
    UPDATE conversations
    SET customer_id = p_target_customer_id
    WHERE customer_id = v_old_customer_id;

    -- Tüm dosyaları taşı
    UPDATE customer_files
    SET customer_id = p_target_customer_id
    WHERE customer_id = v_old_customer_id;

    -- Geçici müşteriyi sil (eğer başka numarası veya konuşması kalmadıysa)
    DELETE FROM customers
    WHERE id = v_old_customer_id
      AND NOT EXISTS (
        SELECT 1 FROM customer_phone_numbers WHERE customer_id = v_old_customer_id
      )
      AND NOT EXISTS (
        SELECT 1 FROM conversations WHERE customer_id = v_old_customer_id
      );
  END IF;
END;
$$;

-- ─────────────────────────────────────────
-- Realtime için replica identity
-- ─────────────────────────────────────────
ALTER TABLE customer_phone_numbers REPLICA IDENTITY FULL;

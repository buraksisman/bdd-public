-- Migration 002: Row Level Security Policies
-- N8N service_role key kullanır (RLS bypass)
-- Web app authenticated key kullanır (RLS enforce)

-- ─────────────────────────────────────────
-- RLS'i aktif et
-- ─────────────────────────────────────────
ALTER TABLE profiles                ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers               ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations           ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages                ENABLE ROW LEVEL SECURITY;
ALTER TABLE attachments             ENABLE ROW LEVEL SECURITY;
ALTER TABLE representative_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_reads      ENABLE ROW LEVEL SECURITY;

-- ─────────────────────────────────────────
-- YARDIMCI FONKSİYON: kullanıcının admin olup olmadığı
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$;

-- ─────────────────────────────────────────
-- profiles
-- ─────────────────────────────────────────
CREATE POLICY "profiles: herkes okuyabilir"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles: kendi kaydını güncelleyebilir"
  ON profiles FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

CREATE POLICY "profiles: admin herkesi güncelleyebilir"
  ON profiles FOR UPDATE
  TO authenticated
  USING (is_admin());

-- ─────────────────────────────────────────
-- customers
-- ─────────────────────────────────────────
CREATE POLICY "customers: herkes okuyabilir"
  ON customers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "customers: herkes güncelleyebilir"
  ON customers FOR UPDATE
  TO authenticated
  USING (true);

-- Insert sadece service_role (N8N) yapar

-- ─────────────────────────────────────────
-- conversations
-- Danışman: kendi konuşmaları + havuz (assigned_to IS NULL)
-- Admin: tüm konuşmalar
-- ─────────────────────────────────────────
CREATE POLICY "conversations: danışman erişimi"
  ON conversations FOR SELECT
  TO authenticated
  USING (
    assigned_to = auth.uid()
    OR assigned_to IS NULL
    OR is_admin()
  );

CREATE POLICY "conversations: danışman güncelleyebilir"
  ON conversations FOR UPDATE
  TO authenticated
  USING (
    assigned_to = auth.uid()
    OR assigned_to IS NULL
    OR is_admin()
  );

-- ─────────────────────────────────────────
-- messages
-- Kullanıcının erişebildiği konuşmaların mesajları
-- ─────────────────────────────────────────
CREATE POLICY "messages: erişilebilir konuşmaların mesajları okunabilir"
  ON messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = messages.conversation_id
        AND (
          c.assigned_to = auth.uid()
          OR c.assigned_to IS NULL
          OR is_admin()
        )
    )
  );

CREATE POLICY "messages: danışman mesaj gönderebilir"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_type = 'agent'
    AND sender_id = auth.uid()
    AND direction = 'outbound'
    AND EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = messages.conversation_id
        AND (c.assigned_to = auth.uid() OR is_admin())
    )
  );

-- ─────────────────────────────────────────
-- attachments
-- ─────────────────────────────────────────
CREATE POLICY "attachments: mesaj sahibi erişebilir"
  ON attachments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM messages m
      JOIN conversations c ON c.id = m.conversation_id
      WHERE m.id = attachments.message_id
        AND (
          c.assigned_to = auth.uid()
          OR c.assigned_to IS NULL
          OR is_admin()
        )
    )
  );

-- ─────────────────────────────────────────
-- representative_sessions
-- ─────────────────────────────────────────
CREATE POLICY "sessions: herkes okuyabilir (online durumu için)"
  ON representative_sessions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "sessions: kendi oturumunu upsert edebilir"
  ON representative_sessions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "sessions: kendi oturumunu güncelleyebilir"
  ON representative_sessions FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

-- ─────────────────────────────────────────
-- conversation_reads
-- ─────────────────────────────────────────
CREATE POLICY "reads: kendi okundu kaydını görebilir"
  ON conversation_reads FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "reads: kendi okundu kaydını yazabilir"
  ON conversation_reads FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "reads: kendi okundu kaydını güncelleyebilir"
  ON conversation_reads FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

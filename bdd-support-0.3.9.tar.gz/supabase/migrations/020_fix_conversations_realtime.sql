-- Migration 020: Fix conversations Realtime + customer_phone_numbers publication
--
-- The conversations SELECT policy used auth.uid() and is_admin() (a subquery).
-- Supabase Realtime silently drops postgres_changes events when the RLS policy
-- contains complex expressions — the same issue was fixed for messages in
-- migration 012. Simplify to USING (true): all authenticated users are company
-- agents in this single-tenant system, and mine/pool filtering is enforced in
-- the query layer (useRealtimeConversations), not at the DB read level.
--
-- Also adds customer_phone_numbers to the realtime publication so that tag
-- edits broadcast to subscribers immediately.

-- ─── conversations SELECT policy ─────────────────────────────────────────────
DROP POLICY IF EXISTS "conversations: danışman erişimi" ON conversations;

CREATE POLICY "conversations: authenticated users can read all"
  ON conversations FOR SELECT
  TO authenticated
  USING (true);

-- ─── customer_phone_numbers: publication + replica identity ──────────────────
ALTER TABLE customer_phone_numbers REPLICA IDENTITY FULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'customer_phone_numbers'
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE customer_phone_numbers';
  END IF;
END $$;

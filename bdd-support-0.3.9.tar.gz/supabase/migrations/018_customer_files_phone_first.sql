-- ───────────────────────────────────────────────────────────────────────
-- customer_files: phone-first
-- ───────────────────────────────────────────────────────────────────────
-- The chat send/receive flow is now keyed by phone, not customer. The
-- customer_files mirror keeps a parallel record so admin cleanup tools
-- can find the storage object — but its primary identity is the phone.

ALTER TABLE customer_files
  ALTER COLUMN customer_id DROP NOT NULL,
  ADD COLUMN IF NOT EXISTS phone_number_id UUID;

ALTER TABLE customer_files
  DROP CONSTRAINT IF EXISTS customer_files_phone_number_id_fkey;
ALTER TABLE customer_files
  ADD CONSTRAINT customer_files_phone_number_id_fkey
    FOREIGN KEY (phone_number_id) REFERENCES customer_phone_numbers(id)
    ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_customer_files_phone_number_id
  ON customer_files(phone_number_id);

-- Migration 003: Stored Functions

-- ─────────────────────────────────────────
-- claim_conversation: Atomik havuz konuşması talep etme
-- Race condition koruması: sadece assigned_to IS NULL ise günceller
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION claim_conversation(
  p_conversation_id UUID,
  p_user_id         UUID
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE conversations
  SET assigned_to = p_user_id,
      updated_at  = NOW()
  WHERE id          = p_conversation_id
    AND assigned_to IS NULL;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Bu konuşma başka bir danışman tarafından alınmış.';
  END IF;
END;
$$;

-- ─────────────────────────────────────────
-- update_heartbeat: Danışman online durumu güncelleme
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_heartbeat(
  p_user_id              UUID,
  p_conversation_id      UUID DEFAULT NULL
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO representative_sessions (user_id, last_seen_at, is_online, current_conversation_id, updated_at)
  VALUES (p_user_id, NOW(), true, p_conversation_id, NOW())
  ON CONFLICT (user_id) DO UPDATE
    SET last_seen_at            = NOW(),
        is_online               = true,
        current_conversation_id = COALESCE(
          EXCLUDED.current_conversation_id,
          representative_sessions.current_conversation_id
        ),
        updated_at              = NOW();
END;
$$;

-- ─────────────────────────────────────────
-- mark_offline: Danışmanı offline işaretle (logout'ta)
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION mark_offline(p_user_id UUID)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE representative_sessions
  SET is_online               = false,
      current_conversation_id = NULL,
      updated_at              = NOW()
  WHERE user_id = p_user_id;
END;
$$;

-- ─────────────────────────────────────────
-- mark_conversation_read: Konuşmayı okundu işaretle
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION mark_conversation_read(
  p_user_id         UUID,
  p_conversation_id UUID
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO conversation_reads (user_id, conversation_id, last_read_at)
  VALUES (p_user_id, p_conversation_id, NOW())
  ON CONFLICT (user_id, conversation_id) DO UPDATE
    SET last_read_at = NOW();
END;
$$;

-- ─────────────────────────────────────────
-- handle_new_user: Yeni auth kullanıcısı için profil oluştur
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, auth AS $$
BEGIN
  INSERT INTO profiles (id, full_name, email)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.email
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ───────────────────────────���─────────────
-- window_expires_at: last_customer_msg_at değişince otomatik güncelle
-- GENERATED ALWAYS AS timestamptz+interval immutable değil, trigger kullan
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_window_expires_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.last_customer_msg_at IS NOT NULL THEN
    NEW.window_expires_at := NEW.last_customer_msg_at + INTERVAL '24 hours';
  ELSE
    NEW.window_expires_at := NULL;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_conversations_window
  BEFORE INSERT OR UPDATE OF last_customer_msg_at ON conversations
  FOR EACH ROW EXECUTE FUNCTION update_window_expires_at();

-- Add per-agent theme preference to profiles
-- Default 'light' so existing rows are unaffected
ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS theme TEXT NOT NULL DEFAULT 'light'
    CHECK (theme IN ('light', 'dark'));

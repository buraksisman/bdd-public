-- Migration 032: Snapshot WhatsApp profile name on first inbound message
-- ─────────────────────────────────────────────────────────────────────────────
-- Display rule (from product owner):
--   "If a msg from new number arrives or a new conversation is started with a
--    new number, the displayed name on the conversation should be updated to
--    the WA name. If no msg arrived, it should stay as a phone number."
--
-- Today:
--   • conversation.display_name is populated at INSERT time from
--     customer_phone_numbers.whatsapp_name (migration 017).
--   • For AGENT-initiated conversations, that value is NULL because no
--     inbound has happened yet — display falls back to the phone number.
--   • When the customer replies, register_inbound_phone backfills
--     customer_phone_numbers.whatsapp_name on first sight, but the
--     conversations row keeps display_name = NULL indefinitely.
--
-- Fix: when the first (or any) inbound message lands, also copy whatsapp_name
-- onto conversation.display_name if it is still NULL. This keeps the
-- conversation row as the canonical, snapshot-stable source of the rendered
-- name and unblocks every consumer that reads display_name directly.

CREATE OR REPLACE FUNCTION update_window_from_inbound_message()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_wa_name TEXT;
BEGIN
  IF NEW.direction = 'inbound' THEN
    -- Look up the latest WhatsApp profile name for this conversation's phone.
    SELECT cpn.whatsapp_name
    INTO v_wa_name
    FROM conversations c
    JOIN customer_phone_numbers cpn ON cpn.id = c.phone_number_id
    WHERE c.id = NEW.conversation_id;

    UPDATE conversations
    SET
      last_customer_msg_at = NEW.created_at,
      window_expires_at    = NEW.created_at + INTERVAL '24 hours',
      status               = CASE WHEN status = 'resolved' THEN 'open' ELSE status END,
      display_name         = COALESCE(NULLIF(display_name, ''), v_wa_name)
    WHERE id = NEW.conversation_id;
  END IF;
  RETURN NEW;
END;
$$;

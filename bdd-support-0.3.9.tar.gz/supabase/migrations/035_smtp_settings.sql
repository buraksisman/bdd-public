-- SMTP is configured from the admin panel. Only the service role can access
-- this table; authenticated browser clients have no direct policies.
CREATE TABLE smtp_settings (
  id                 BOOLEAN PRIMARY KEY DEFAULT TRUE CHECK (id),
  host               TEXT NOT NULL DEFAULT '',
  port               INTEGER NOT NULL DEFAULT 587 CHECK (port BETWEEN 1 AND 65535),
  secure             BOOLEAN NOT NULL DEFAULT FALSE,
  username           TEXT NOT NULL DEFAULT '',
  password_encrypted TEXT,
  from_name          TEXT NOT NULL DEFAULT 'BDD Destek',
  from_email         TEXT NOT NULL DEFAULT '',
  enabled            BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by         UUID REFERENCES profiles(id) ON DELETE SET NULL
);

ALTER TABLE smtp_settings ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON smtp_settings FROM anon, authenticated;
GRANT ALL ON smtp_settings TO service_role;

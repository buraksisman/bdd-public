-- Allow authenticated agents to insert attachment rows for messages they sent.
-- Without this policy, sendMediaMessage's attachment insert is silently
-- denied by RLS, leaving the message stuck at status='creating' with no file.
CREATE POLICY "attachments: agents can insert for own messages"
  ON attachments FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM messages m
      JOIN conversations c ON c.id = m.conversation_id
      WHERE m.id = attachments.message_id
        AND (c.assigned_to = auth.uid() OR is_admin())
    )
  );

-- Allow agents to update messages in their own conversations.
-- Without this, the status flip from 'creating' → 'pending' is silently
-- denied, so N8N never sees the outbound message.
CREATE POLICY "messages: agents can update own conversation messages"
  ON messages FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = messages.conversation_id
        AND (c.assigned_to = auth.uid() OR is_admin())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = messages.conversation_id
        AND (c.assigned_to = auth.uid() OR is_admin())
    )
  );

-- Migration 010: Add direction to customer_files
ALTER TABLE customer_files
  ADD COLUMN IF NOT EXISTS direction TEXT NOT NULL DEFAULT 'outbound'
  CHECK (direction IN ('inbound', 'outbound'));

CREATE INDEX IF NOT EXISTS idx_customer_files_direction ON customer_files(customer_id, direction);

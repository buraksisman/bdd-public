-- 1. Allow 'creating' status on messages so the outbound media flow can insert
--    a message with attachment-pending state without violating the check constraint.
ALTER TABLE messages DROP CONSTRAINT IF EXISTS messages_status_check;
ALTER TABLE messages ADD CONSTRAINT messages_status_check
  CHECK (status = ANY (ARRAY['creating'::text, 'pending'::text, 'sent'::text, 'delivered'::text, 'read'::text, 'failed'::text]));

-- 2. Simplify attachments SELECT RLS. Complex EXISTS subqueries silently
--    block Supabase Realtime from delivering postgres_changes events.
DROP POLICY IF EXISTS "attachments: mesaj sahibi erişebilir" ON attachments;
CREATE POLICY "attachments: authenticated users can read all"
  ON attachments FOR SELECT
  TO authenticated
  USING (true);

-- 3. REPLICA IDENTITY FULL is required for filtered Realtime subscriptions.
ALTER TABLE attachments REPLICA IDENTITY FULL;

-- 4. Add attachments to the supabase_realtime publication. Without this,
--    no INSERT events on attachments are ever published, so the chatbox
--    never receives the file row even though the message row arrives.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'attachments'
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE attachments';
  END IF;
END $$;

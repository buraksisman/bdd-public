-- Restore conversation privacy at the database boundary.
-- Admins can read every conversation. Agents can read only conversations
-- assigned to them or waiting in the shared pool. N8N keeps service_role
-- access and therefore bypasses these policies.

DROP POLICY IF EXISTS "conversations: authenticated users can read all" ON conversations;
DROP POLICY IF EXISTS "conversations: danışman erişimi" ON conversations;

CREATE POLICY "conversations: assigned pool or admin read"
  ON conversations FOR SELECT
  TO authenticated
  USING (
    assigned_to = auth.uid()
    OR assigned_to IS NULL
    OR is_admin()
  );

DROP POLICY IF EXISTS "messages: authenticated users can read all messages" ON messages;
DROP POLICY IF EXISTS "messages: erişilebilir konuşmaların mesajları okunabilir" ON messages;

CREATE POLICY "messages: assigned pool or admin read"
  ON messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM conversations c
      WHERE c.id = messages.conversation_id
        AND (
          c.assigned_to = auth.uid()
          OR c.assigned_to IS NULL
          OR is_admin()
        )
    )
  );

DROP POLICY IF EXISTS "attachments: authenticated users can read all" ON attachments;
DROP POLICY IF EXISTS "attachments: mesaj sahibi erişebilir" ON attachments;

CREATE POLICY "attachments: assigned pool or admin read"
  ON attachments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM messages m
      JOIN conversations c ON c.id = m.conversation_id
      WHERE m.id = attachments.message_id
        AND (
          c.assigned_to = auth.uid()
          OR c.assigned_to IS NULL
          OR is_admin()
        )
    )
  );

CREATE OR REPLACE FUNCTION mark_conversation_read(
  p_user_id UUID,
  p_conversation_id UUID
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
BEGIN
  IF p_user_id IS DISTINCT FROM auth.uid() THEN
    RAISE EXCEPTION 'forbidden';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM conversations c
    WHERE c.id = p_conversation_id
      AND (c.assigned_to = auth.uid() OR c.assigned_to IS NULL OR is_admin())
  ) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;

  INSERT INTO conversation_reads (user_id, conversation_id, last_read_at)
  VALUES (p_user_id, p_conversation_id, NOW())
  ON CONFLICT (user_id, conversation_id) DO UPDATE
    SET last_read_at = NOW();

  UPDATE conversations
  SET unread_count = 0
  WHERE id = p_conversation_id AND unread_count > 0;
END;
$$;

-- If Meta reports that an unread inbound message was deleted, remove that
-- message from the shared unread total without allowing the value below zero.
CREATE OR REPLACE FUNCTION decrement_unread_for_deleted_message()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF OLD.deleted_at IS NULL AND NEW.deleted_at IS NOT NULL AND NEW.direction = 'inbound' THEN
    UPDATE conversations
    SET unread_count = GREATEST(unread_count - 1, 0)
    WHERE id = NEW.conversation_id AND unread_count > 0;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_message_deleted_update_unread ON messages;
CREATE TRIGGER on_message_deleted_update_unread
  AFTER UPDATE OF deleted_at ON messages
  FOR EACH ROW EXECUTE FUNCTION decrement_unread_for_deleted_message();
